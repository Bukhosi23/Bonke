import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPlantSchema, insertUserSchema, insertUserPlantSchema, insertCommunityPostSchema, insertIdentificationHistorySchema, insertCarbonTrackingSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Plants API
  app.get("/api/plants", async (req: Request, res: Response) => {
    try {
      const searchTerm = req.query.search as string | undefined;
      
      if (searchTerm) {
        const plants = await storage.getPlantsBySearchTerm(searchTerm);
        res.json(plants);
      } else {
        const plants = await storage.getPlants();
        res.json(plants);
      }
    } catch (error) {
      console.error("Error fetching plants:", error);
      res.status(500).json({ message: "Error fetching plants" });
    }
  });
  
  app.get("/api/plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const plant = await storage.getPlant(id);
      
      if (!plant) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      res.json(plant);
    } catch (error) {
      console.error("Error fetching plant:", error);
      res.status(500).json({ message: "Error fetching plant" });
    }
  });
  
  app.post("/api/plants", async (req: Request, res: Response) => {
    try {
      const plantData = insertPlantSchema.parse(req.body);
      const plant = await storage.createPlant(plantData);
      res.status(201).json(plant);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid plant data", errors: error.errors });
      }
      console.error("Error creating plant:", error);
      res.status(500).json({ message: "Error creating plant" });
    }
  });
  
  // User Plants API
  app.get("/api/user-plants/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const userPlants = await storage.getUserPlants(userId);
      res.json(userPlants);
    } catch (error) {
      console.error("Error fetching user plants:", error);
      res.status(500).json({ message: "Error fetching user plants" });
    }
  });
  
  app.post("/api/user-plants", async (req: Request, res: Response) => {
    try {
      const userPlantData = insertUserPlantSchema.parse(req.body);
      const userPlant = await storage.createUserPlant(userPlantData);
      res.status(201).json(userPlant);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid user plant data", errors: error.errors });
      }
      console.error("Error creating user plant:", error);
      res.status(500).json({ message: "Error creating user plant" });
    }
  });
  
  app.patch("/api/user-plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedUserPlant = await storage.updateUserPlant(id, req.body);
      
      if (!updatedUserPlant) {
        return res.status(404).json({ message: "User plant not found" });
      }
      
      res.json(updatedUserPlant);
    } catch (error) {
      console.error("Error updating user plant:", error);
      res.status(500).json({ message: "Error updating user plant" });
    }
  });
  
  app.delete("/api/user-plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteUserPlant(id);
      
      if (!success) {
        return res.status(404).json({ message: "User plant not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user plant:", error);
      res.status(500).json({ message: "Error deleting user plant" });
    }
  });
  
  // Community Posts API
  app.get("/api/community-posts", async (req: Request, res: Response) => {
    try {
      const posts = await storage.getCommunityPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching community posts:", error);
      res.status(500).json({ message: "Error fetching community posts" });
    }
  });
  
  app.get("/api/community-posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getCommunityPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Community post not found" });
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error fetching community post:", error);
      res.status(500).json({ message: "Error fetching community post" });
    }
  });
  
  app.post("/api/community-posts", async (req: Request, res: Response) => {
    try {
      const postData = insertCommunityPostSchema.parse(req.body);
      const post = await storage.createCommunityPost(postData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid community post data", errors: error.errors });
      }
      console.error("Error creating community post:", error);
      res.status(500).json({ message: "Error creating community post" });
    }
  });
  
  app.post("/api/community-posts/:id/like", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedPost = await storage.likeCommunityPost(id);
      
      if (!updatedPost) {
        return res.status(404).json({ message: "Community post not found" });
      }
      
      res.json(updatedPost);
    } catch (error) {
      console.error("Error liking community post:", error);
      res.status(500).json({ message: "Error liking community post" });
    }
  });
  
  // Plant Identification API
  app.get("/api/identification-history/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const history = await storage.getIdentificationHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching identification history:", error);
      res.status(500).json({ message: "Error fetching identification history" });
    }
  });
  
  app.post("/api/identify-plant", async (req: Request, res: Response) => {
    try {
      const plantImageUrl = req.body.imageUrl;
      
      if (!plantImageUrl) {
        return res.status(400).json({ message: "Image URL is required" });
      }
      
      // Import OpenAI service here to avoid top-level import issues
      const { identifyPlantWithOpenAI, getMockPlantIdentification } = await import('./services/openaiService');
      
      // Try to identify with OpenAI first, fall back to mock if not available
      let identificationResult = await identifyPlantWithOpenAI(plantImageUrl);
      
      // If OpenAI identification failed, use mock identification
      if (!identificationResult) {
        const fileName = req.body.fileName || '';
        console.log("Using mock plant identification for:", plantImageUrl.substring(0, 50) + "...");
        console.log("Filename hint:", fileName);
        identificationResult = getMockPlantIdentification(plantImageUrl, fileName);
      }
      
      // Store the identified plant in our database
      const plants = await storage.getPlants();
      let plantId: number;
      
      // Try to find a matching plant in our database
      const matchingPlant = plants.find(p => 
        p.commonName.toLowerCase() === identificationResult.commonName.toLowerCase() ||
        p.scientificName.toLowerCase() === identificationResult.scientificName.toLowerCase()
      );
      
      if (matchingPlant) {
        // Use the matching plant's ID
        plantId = matchingPlant.id;
        identificationResult.plantId = plantId;
      } else {
        // Create a new plant entry
        try {
          const newPlant = await storage.createPlant({
            commonName: identificationResult.commonName,
            scientificName: identificationResult.scientificName,
            description: identificationResult.description || "A beautiful plant specimen.",
            careLevel: identificationResult.careLevel || "moderate",
            waterFrequency: "Check soil moisture regularly",
            lightRequirements: "Depends on species",
            temperature: "65-85°F (18-30°C)",
            humidity: "Average to high",
            imageUrl: plantImageUrl,
            carbonImpact: 250
          });
          
          plantId = newPlant.id;
          identificationResult.plantId = plantId;
        } catch (error) {
          console.error("Error creating new plant:", error);
          // Use a default ID if creation fails
          plantId = 1;
          identificationResult.plantId = plantId;
        }
      }
      
      // If there's a userId, save to identification history
      if (req.body.userId) {
        const historyData = insertIdentificationHistorySchema.parse({
          userId: req.body.userId,
          imageUrl: plantImageUrl,
          results: identificationResult,
          confidence: identificationResult.confidence
        });
        
        await storage.createIdentificationHistory(historyData);
      }
      
      res.json(identificationResult);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid identification data", errors: error.errors });
      }
      console.error("Error identifying plant:", error);
      res.status(500).json({ message: "Error identifying plant" });
    }
  });
  
  // Carbon Tracking API
  app.get("/api/carbon-tracking/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const tracking = await storage.getCarbonTracking(userId);
      
      if (!tracking) {
        // If no tracking exists, return zero values
        return res.json({
          userId,
          totalPlants: 0,
          co2Absorbed: 0,
          oxygenProduced: 0,
          airPurified: 0,
          lastUpdated: new Date()
        });
      }
      
      res.json(tracking);
    } catch (error) {
      console.error("Error fetching carbon tracking:", error);
      res.status(500).json({ message: "Error fetching carbon tracking" });
    }
  });
  
  app.post("/api/carbon-tracking", async (req: Request, res: Response) => {
    try {
      const trackingData = insertCarbonTrackingSchema.parse(req.body);
      const tracking = await storage.createOrUpdateCarbonTracking(trackingData);
      res.json(tracking);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid carbon tracking data", errors: error.errors });
      }
      console.error("Error updating carbon tracking:", error);
      res.status(500).json({ message: "Error updating carbon tracking" });
    }
  });
  
  // User API (for authentication in a real app)
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // In a real app, we would hash the password before storing
      const user = await storage.createUser(userData);
      
      // Don't return the password in the response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Error creating user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
