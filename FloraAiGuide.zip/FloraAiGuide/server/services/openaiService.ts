import OpenAI from 'openai';

// Check if OpenAI API key is configured
const isOpenAiConfigured = (): boolean => {
  const apiKey = process.env.OPENAI_API_KEY;
  const isConfigured = !!apiKey;
  console.log(`OpenAI API key configured: ${isConfigured}`);
  return isConfigured;
};

// Create OpenAI client if API key is available
let openai: OpenAI | null = null;
try {
  if (isOpenAiConfigured()) {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    console.log("OpenAI client initialized successfully");
  } else {
    console.warn("OpenAI API key not found. Plant identification will use mock data.");
  }
} catch (error) {
  console.error("Error initializing OpenAI client:", error);
}

interface PlantIdentificationResult {
  plantId: number;
  commonName: string;
  scientificName: string;
  confidence: number;
  description?: string;
  careLevel?: string;
  matches: {
    plantId: number;
    name: string;
    confidence: number;
  }[];
}

// Function to identify plants using OpenAI's vision capabilities
export async function identifyPlantWithOpenAI(imageUrl: string): Promise<PlantIdentificationResult | null> {
  console.log("Attempting to identify plant with OpenAI");
  
  if (!openai) {
    console.warn("OpenAI client not initialized. Cannot perform plant identification.");
    return null;
  }
  
  console.log("OpenAI client is available, proceeding with identification");

  try {
    // Convert the URL to base64 if it's a data URL
    let imageContent = imageUrl;
    if (imageUrl.startsWith('data:')) {
      imageContent = imageUrl;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a plant identification expert. Analyze the image and identify the plant. 
                    Return a JSON object with the following structure:
                    {
                      "commonName": "Common plant name",
                      "scientificName": "Scientific plant name",
                      "confidence": number from 1-100,
                      "description": "Brief description of the plant",
                      "careLevel": "easy", "moderate", or "difficult",
                      "matches": [
                        {
                          "name": "Primary match name",
                          "confidence": number from 1-100
                        },
                        {
                          "name": "Secondary match name",
                          "confidence": number from 1-100
                        },
                        {
                          "name": "Tertiary match name",
                          "confidence": number from 1-100
                        }
                      ]
                    }`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Identify this plant and provide detailed information."
            },
            {
              type: "image_url",
              image_url: {
                url: imageContent
              }
            }
          ],
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Validate and format the response
    if (!result.commonName || !result.scientificName) {
      throw new Error("Invalid identification result from OpenAI");
    }

    return {
      plantId: 0, // Will be assigned by the database
      commonName: result.commonName,
      scientificName: result.scientificName,
      confidence: result.confidence || 85,
      description: result.description,
      careLevel: result.careLevel || "moderate",
      matches: result.matches?.map((match: any, i: number) => ({
        plantId: i,
        name: match.name,
        confidence: match.confidence
      })) || []
    };
  } catch (error) {
    console.error("Error identifying plant with OpenAI:", error);
    return null;
  }
}

// Mock function for when OpenAI is not available
export function getMockPlantIdentification(imageUrl: string, fileName?: string): PlantIdentificationResult {
  // Check if the image URL or filename contains descriptive terms we can use
  const url = imageUrl.toLowerCase();
  const name = fileName?.toLowerCase() || '';
  
  // Detect black roses or specific plants from URL or filename
  let plantName = "Unknown Plant";
  let scientificName = "Plantus unknownus";
  let confidence = 75;
  let description = "This appears to be a plant with distinctive characteristics.";
  let careLevel = "moderate";
  
  // Check for black rose
  if (url.includes('rose') || name.includes('rose') || 
      url.includes('black') || name.includes('black')) {
    plantName = "Black Rose";
    scientificName = "Aeonium arboreum 'Zwartkop'";
    confidence = 92;
    description = "Often called Black Rose or Black Rose Tree, this succulent forms rosettes of dark purple, almost black leaves. Despite its common name, it's not a true rose but a succulent in the Crassulaceae family.";
    careLevel = "easy";
  }
  // Check for monstera
  else if (url.includes('monstera') || name.includes('monstera') || 
           url.includes('swiss') || name.includes('cheese')) {
    plantName = "Monstera Deliciosa";
    scientificName = "Monstera deliciosa";
    confidence = 94;
    description = "Known for its iconic split leaves, the Monstera Deliciosa is a popular houseplant native to tropical forests of southern Mexico and Panama.";
    careLevel = "easy";
  }
  // Check for snake plant
  else if (url.includes('snake') || name.includes('snake') || 
           url.includes('sansevieria') || name.includes('mother-in-law')) {
    plantName = "Snake Plant";
    scientificName = "Dracaena trifasciata";
    confidence = 90;
    description = "The Snake Plant, also known as Mother-in-Law's Tongue, is a hardy succulent with tall, stiff leaves that can range from deep green with gray-green cross-banding to yellow borders.";
    careLevel = "easy";
  }
  
  return {
    plantId: 1,
    commonName: plantName,
    scientificName: scientificName,
    confidence: confidence,
    description: description,
    careLevel: careLevel,
    matches: [
      {
        plantId: 1,
        name: plantName,
        confidence: confidence
      },
      {
        plantId: 2,
        name: "Monstera Deliciosa",
        confidence: Math.floor(Math.random() * 25) + 40
      },
      {
        plantId: 3,
        name: "Snake Plant",
        confidence: Math.floor(Math.random() * 20) + 30
      }
    ]
  };
}