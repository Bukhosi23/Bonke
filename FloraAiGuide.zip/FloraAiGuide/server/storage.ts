import {
  users,
  plants,
  userPlants,
  communityPosts,
  identificationHistory,
  carbonTracking,
  type User,
  type InsertUser,
  type Plant,
  type InsertPlant,
  type UserPlant,
  type InsertUserPlant,
  type CommunityPost,
  type InsertCommunityPost,
  type IdentificationHistory,
  type InsertIdentificationHistory,
  type CarbonTracking,
  type InsertCarbonTracking
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Plant methods
  getPlant(id: number): Promise<Plant | undefined>;
  getPlants(): Promise<Plant[]>;
  getPlantsBySearchTerm(searchTerm: string): Promise<Plant[]>;
  createPlant(plant: InsertPlant): Promise<Plant>;
  
  // User Plants methods
  getUserPlants(userId: number): Promise<UserPlant[]>;
  getUserPlant(id: number): Promise<UserPlant | undefined>;
  createUserPlant(userPlant: InsertUserPlant): Promise<UserPlant>;
  updateUserPlant(id: number, userPlant: Partial<UserPlant>): Promise<UserPlant | undefined>;
  deleteUserPlant(id: number): Promise<boolean>;
  
  // Community Posts methods
  getCommunityPosts(): Promise<CommunityPost[]>;
  getCommunityPost(id: number): Promise<CommunityPost | undefined>;
  createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost>;
  likeCommunityPost(id: number): Promise<CommunityPost | undefined>;
  
  // Identification History methods
  getIdentificationHistory(userId: number): Promise<IdentificationHistory[]>;
  createIdentificationHistory(history: InsertIdentificationHistory): Promise<IdentificationHistory>;
  
  // Carbon Tracking methods
  getCarbonTracking(userId: number): Promise<CarbonTracking | undefined>;
  createOrUpdateCarbonTracking(tracking: InsertCarbonTracking): Promise<CarbonTracking>;
}

// We'll keep the MemStorage implementation for local testing
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private plants: Map<number, Plant>;
  private userPlants: Map<number, UserPlant>;
  private communityPosts: Map<number, CommunityPost>;
  private identificationHistory: Map<number, IdentificationHistory>;
  private carbonTracking: Map<number, CarbonTracking>;
  
  private userIdCounter: number;
  private plantIdCounter: number;
  private userPlantIdCounter: number;
  private communityPostIdCounter: number;
  private identificationHistoryIdCounter: number;
  private carbonTrackingIdCounter: number;
  
  constructor() {
    this.users = new Map();
    this.plants = new Map();
    this.userPlants = new Map();
    this.communityPosts = new Map();
    this.identificationHistory = new Map();
    this.carbonTracking = new Map();
    
    this.userIdCounter = 1;
    this.plantIdCounter = 1;
    this.userPlantIdCounter = 1;
    this.communityPostIdCounter = 1;
    this.identificationHistoryIdCounter = 1;
    this.carbonTrackingIdCounter = 1;
    
    // Add some initial plants for demo purposes
    this.initializePlants();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      displayName: insertUser.displayName || null,
      avatar: insertUser.avatar || null
    };
    this.users.set(id, user);
    return user;
  }
  
  // Plant methods
  async getPlant(id: number): Promise<Plant | undefined> {
    return this.plants.get(id);
  }
  
  async getPlants(): Promise<Plant[]> {
    return Array.from(this.plants.values());
  }
  
  async getPlantsBySearchTerm(searchTerm: string): Promise<Plant[]> {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    return Array.from(this.plants.values()).filter(
      (plant) => 
        plant.commonName.toLowerCase().includes(lowerCaseSearchTerm) ||
        plant.scientificName.toLowerCase().includes(lowerCaseSearchTerm)
    );
  }
  
  async createPlant(insertPlant: InsertPlant): Promise<Plant> {
    const id = this.plantIdCounter++;
    const plant: Plant = { 
      ...insertPlant, 
      id,
      imageUrl: insertPlant.imageUrl || null,
      carbonImpact: insertPlant.carbonImpact || null
    };
    this.plants.set(id, plant);
    return plant;
  }
  
  // User Plants methods
  async getUserPlants(userId: number): Promise<UserPlant[]> {
    return Array.from(this.userPlants.values()).filter(
      (userPlant) => userPlant.userId === userId
    );
  }
  
  async getUserPlant(id: number): Promise<UserPlant | undefined> {
    return this.userPlants.get(id);
  }
  
  async createUserPlant(insertUserPlant: InsertUserPlant): Promise<UserPlant> {
    const id = this.userPlantIdCounter++;
    const now = new Date();
    const userPlant: UserPlant = { 
      ...insertUserPlant, 
      id,
      acquiredDate: now,
      nickname: insertUserPlant.nickname || null,
      lastWatered: insertUserPlant.lastWatered || null,
      waterSchedule: insertUserPlant.waterSchedule || null,
      notes: insertUserPlant.notes || null,
      health: insertUserPlant.health || null
    };
    this.userPlants.set(id, userPlant);
    return userPlant;
  }
  
  async updateUserPlant(id: number, userPlantUpdate: Partial<UserPlant>): Promise<UserPlant | undefined> {
    const userPlant = this.userPlants.get(id);
    if (!userPlant) return undefined;
    
    const updatedUserPlant = { ...userPlant, ...userPlantUpdate };
    this.userPlants.set(id, updatedUserPlant);
    return updatedUserPlant;
  }
  
  async deleteUserPlant(id: number): Promise<boolean> {
    return this.userPlants.delete(id);
  }
  
  // Community Posts methods
  async getCommunityPosts(): Promise<CommunityPost[]> {
    return Array.from(this.communityPosts.values())
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
  }
  
  async getCommunityPost(id: number): Promise<CommunityPost | undefined> {
    return this.communityPosts.get(id);
  }
  
  async createCommunityPost(insertPost: InsertCommunityPost): Promise<CommunityPost> {
    const id = this.communityPostIdCounter++;
    const now = new Date();
    const post: CommunityPost = { 
      ...insertPost, 
      id,
      likes: 0,
      createdAt: now,
      imageUrl: insertPost.imageUrl || null
    };
    this.communityPosts.set(id, post);
    return post;
  }
  
  async likeCommunityPost(id: number): Promise<CommunityPost | undefined> {
    const post = this.communityPosts.get(id);
    if (!post) return undefined;
    
    // Handle possibly null likes
    const currentLikes = post.likes || 0; 
    const updatedPost = { ...post, likes: currentLikes + 1 };
    this.communityPosts.set(id, updatedPost);
    return updatedPost;
  }
  
  // Identification History methods
  async getIdentificationHistory(userId: number): Promise<IdentificationHistory[]> {
    return Array.from(this.identificationHistory.values())
      .filter(history => history.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
  }
  
  async createIdentificationHistory(insertHistory: InsertIdentificationHistory): Promise<IdentificationHistory> {
    const id = this.identificationHistoryIdCounter++;
    const now = new Date();
    const history: IdentificationHistory = {
      ...insertHistory,
      id,
      createdAt: now,
      userId: insertHistory.userId || null
    };
    this.identificationHistory.set(id, history);
    return history;
  }
  
  // Carbon Tracking methods
  async getCarbonTracking(userId: number): Promise<CarbonTracking | undefined> {
    return Array.from(this.carbonTracking.values()).find(
      (tracking) => tracking.userId === userId
    );
  }
  
  async createOrUpdateCarbonTracking(insertTracking: InsertCarbonTracking): Promise<CarbonTracking> {
    const existingTracking = await this.getCarbonTracking(insertTracking.userId);
    const now = new Date();
    
    if (existingTracking) {
      const updatedTracking: CarbonTracking = {
        ...existingTracking,
        ...insertTracking,
        lastUpdated: now
      };
      this.carbonTracking.set(existingTracking.id, updatedTracking);
      return updatedTracking;
    }
    
    const id = this.carbonTrackingIdCounter++;
    const newTracking: CarbonTracking = {
      ...insertTracking,
      id,
      lastUpdated: now
    };
    this.carbonTracking.set(id, newTracking);
    return newTracking;
  }
  
  private initializePlants() {
    const initialPlants: InsertPlant[] = [
      {
        commonName: "Monstera Deliciosa",
        scientificName: "Monstera deliciosa",
        description: "The Swiss Cheese Plant, known for its distinctive holes and notches in its leaves, is a popular houseplant native to the tropical forests of southern Mexico.",
        careLevel: "moderate",
        waterFrequency: "Weekly, allowing soil to dry between waterings",
        lightRequirements: "Bright, indirect light",
        temperature: "65-85°F (18-30°C)",
        humidity: "Medium to high",
        imageUrl: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b",
        carbonImpact: 320
      },
      {
        commonName: "Snake Plant",
        scientificName: "Sansevieria trifasciata",
        description: "Also known as Mother-in-Law's Tongue, this plant is nearly indestructible and perfect for beginners.",
        careLevel: "easy",
        waterFrequency: "Every 2-3 weeks, allowing soil to dry completely",
        lightRequirements: "Any light level, from low to bright indirect",
        temperature: "60-85°F (15-30°C)",
        humidity: "Any humidity level",
        imageUrl: "https://images.unsplash.com/photo-1593482892290-f54227b4699b",
        carbonImpact: 250
      },
      {
        commonName: "Fiddle Leaf Fig",
        scientificName: "Ficus lyrata",
        description: "Popular for its large, violin-shaped leaves, the Fiddle Leaf Fig makes a dramatic statement in any space.",
        careLevel: "difficult",
        waterFrequency: "Weekly, allowing top inch of soil to dry",
        lightRequirements: "Bright, indirect light",
        temperature: "65-75°F (18-24°C)",
        humidity: "Medium to high",
        imageUrl: "https://images.unsplash.com/photo-1597055181900-23778533afd9",
        carbonImpact: 380
      },
      {
        commonName: "Peace Lily",
        scientificName: "Spathiphyllum",
        description: "Known for its air-purifying qualities and elegant white flowers, the Peace Lily is a classic houseplant.",
        careLevel: "easy",
        waterFrequency: "When leaves begin to droop slightly",
        lightRequirements: "Low to medium indirect light",
        temperature: "65-80°F (18-27°C)",
        humidity: "Medium to high",
        imageUrl: "https://images.unsplash.com/photo-1593482892385-f3e6f7731494",
        carbonImpact: 280
      },
      {
        commonName: "Pothos",
        scientificName: "Epipremnum aureum",
        description: "A trailing vine with heart-shaped leaves that's incredibly easy to care for and propagate.",
        careLevel: "easy",
        waterFrequency: "Every 1-2 weeks, allowing soil to dry between waterings",
        lightRequirements: "Low to bright indirect light",
        temperature: "60-80°F (15-27°C)",
        humidity: "Any humidity level",
        imageUrl: "https://images.unsplash.com/photo-1572688484438-313a6e50c333",
        carbonImpact: 200
      },
      {
        commonName: "Aloe Vera",
        scientificName: "Aloe barbadensis miller",
        description: "A succulent plant known for its medicinal properties and fleshy, pointed leaves.",
        careLevel: "easy",
        waterFrequency: "Every 2-3 weeks, allowing soil to dry completely",
        lightRequirements: "Bright, indirect light",
        temperature: "55-80°F (13-27°C)",
        humidity: "Low",
        imageUrl: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09",
        carbonImpact: 150
      }
    ];
    
    initialPlants.forEach(plant => {
      this.createPlant(plant);
    });
    
    // Add some initial community posts
    const demoPost1: InsertCommunityPost = {
      userId: 1,
      title: "My monstera has three new leaves this month!",
      content: "What's your secret for fast growth? #PlantProgress",
      imageUrl: "https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e",
    };
    
    const demoPost2: InsertCommunityPost = {
      userId: 2,
      title: "Help! What's wrong with my fiddle leaf fig?",
      content: "The leaves are turning brown at the edges. Any advice would be appreciated!",
      imageUrl: "https://images.unsplash.com/photo-1599009944997-3544f382d585",
    };
    
    this.createCommunityPost(demoPost1);
    this.createCommunityPost(demoPost2);
  }
}

// Import DB connection
import { db } from './db';
import { eq, and, desc, asc, like } from 'drizzle-orm';

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Plant methods
  async getPlant(id: number): Promise<Plant | undefined> {
    const [plant] = await db.select().from(plants).where(eq(plants.id, id));
    return plant;
  }

  async getPlants(): Promise<Plant[]> {
    return await db.select().from(plants);
  }

  async getPlantsBySearchTerm(searchTerm: string): Promise<Plant[]> {
    return await db.select().from(plants).where(
      like(plants.commonName, `%${searchTerm}%`)
    );
  }

  async createPlant(insertPlant: InsertPlant): Promise<Plant> {
    const [plant] = await db
      .insert(plants)
      .values(insertPlant)
      .returning();
    return plant;
  }
  
  // User Plants methods
  async getUserPlants(userId: number): Promise<UserPlant[]> {
    return await db.select()
      .from(userPlants)
      .where(eq(userPlants.userId, userId));
      // Note: createdAt field doesn't exist in userPlants
  }

  async getUserPlant(id: number): Promise<UserPlant | undefined> {
    const [userPlant] = await db.select()
      .from(userPlants)
      .where(eq(userPlants.id, id));
    return userPlant;
  }

  async createUserPlant(insertUserPlant: InsertUserPlant): Promise<UserPlant> {
    const [userPlant] = await db
      .insert(userPlants)
      .values(insertUserPlant)
      .returning();
    return userPlant;
  }

  async updateUserPlant(id: number, userPlantUpdate: Partial<UserPlant>): Promise<UserPlant | undefined> {
    const [updatedUserPlant] = await db
      .update(userPlants)
      .set(userPlantUpdate)
      .where(eq(userPlants.id, id))
      .returning();
    return updatedUserPlant;
  }

  async deleteUserPlant(id: number): Promise<boolean> {
    const result = await db
      .delete(userPlants)
      .where(eq(userPlants.id, id))
      .returning({ deletedId: userPlants.id });
    return result.length > 0;
  }
  
  // Community Posts methods
  async getCommunityPosts(): Promise<CommunityPost[]> {
    return await db.select()
      .from(communityPosts)
      .orderBy(desc(communityPosts.createdAt));
  }

  async getCommunityPost(id: number): Promise<CommunityPost | undefined> {
    const [post] = await db.select()
      .from(communityPosts)
      .where(eq(communityPosts.id, id));
    return post;
  }

  async createCommunityPost(insertPost: InsertCommunityPost): Promise<CommunityPost> {
    const [post] = await db
      .insert(communityPosts)
      .values(insertPost)
      .returning();
    return post;
  }

  async likeCommunityPost(id: number): Promise<CommunityPost | undefined> {
    const [post] = await db.select()
      .from(communityPosts)
      .where(eq(communityPosts.id, id));
    
    if (!post) return undefined;
    
    // Handle null likes value
    const currentLikes = post.likes ?? 0;
    
    const [updatedPost] = await db
      .update(communityPosts)
      .set({ likes: currentLikes + 1 })
      .where(eq(communityPosts.id, id))
      .returning();
    
    return updatedPost;
  }
  
  // Identification History methods
  async getIdentificationHistory(userId: number): Promise<IdentificationHistory[]> {
    return await db.select()
      .from(identificationHistory)
      .where(eq(identificationHistory.userId, userId))
      .orderBy(desc(identificationHistory.createdAt));
  }

  async createIdentificationHistory(insertHistory: InsertIdentificationHistory): Promise<IdentificationHistory> {
    const [history] = await db
      .insert(identificationHistory)
      .values(insertHistory)
      .returning();
    return history;
  }
  
  // Carbon Tracking methods
  async getCarbonTracking(userId: number): Promise<CarbonTracking | undefined> {
    const [tracking] = await db.select()
      .from(carbonTracking)
      .where(eq(carbonTracking.userId, userId));
    return tracking;
  }

  async createOrUpdateCarbonTracking(insertTracking: InsertCarbonTracking): Promise<CarbonTracking> {
    // Check if tracking exists
    const [existingTracking] = await db.select()
      .from(carbonTracking)
      .where(eq(carbonTracking.userId, insertTracking.userId));
    
    if (existingTracking) {
      // Update existing tracking
      const [updatedTracking] = await db
        .update(carbonTracking)
        .set(insertTracking)
        .where(eq(carbonTracking.userId, insertTracking.userId))
        .returning();
      return updatedTracking;
    }
    
    // Create new tracking
    const [newTracking] = await db
      .insert(carbonTracking)
      .values(insertTracking)
      .returning();
    return newTracking;
  }
}

// Use Database storage as default
export const storage = new DatabaseStorage();
