import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  displayName: text("display_name"),
  avatar: text("avatar"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
  avatar: true,
});

// Plant model
export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  commonName: text("common_name").notNull(),
  scientificName: text("scientific_name").notNull(),
  description: text("description").notNull(),
  careLevel: text("care_level").notNull(), // easy, moderate, difficult
  waterFrequency: text("water_frequency").notNull(),
  lightRequirements: text("light_requirements").notNull(),
  temperature: text("temperature").notNull(),
  humidity: text("humidity").notNull(),
  imageUrl: text("image_url"),
  carbonImpact: integer("carbon_impact"),
});

export const insertPlantSchema = createInsertSchema(plants).pick({
  commonName: true,
  scientificName: true,
  description: true,
  careLevel: true,
  waterFrequency: true,
  lightRequirements: true,
  temperature: true,
  humidity: true,
  imageUrl: true,
  carbonImpact: true,
});

// User Plants model (for tracking user's plants)
export const userPlants = pgTable("user_plants", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  plantId: integer("plant_id").notNull(),
  nickname: text("nickname"),
  lastWatered: timestamp("last_watered"),
  waterSchedule: text("water_schedule"),
  notes: text("notes"),
  health: text("health").default("healthy"), // healthy, needs-attention, critical
  acquiredDate: timestamp("acquired_date").defaultNow(),
});

export const insertUserPlantSchema = createInsertSchema(userPlants).pick({
  userId: true,
  plantId: true,
  nickname: true,
  lastWatered: true,
  waterSchedule: true,
  notes: true,
  health: true,
});

// Community Posts model
export const communityPosts = pgTable("community_posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCommunityPostSchema = createInsertSchema(communityPosts).pick({
  userId: true,
  title: true,
  content: true,
  imageUrl: true,
});

// Plant Identification History
export const identificationHistory = pgTable("identification_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  imageUrl: text("image_url").notNull(),
  results: jsonb("results").notNull(), // stores identification results
  confidence: integer("confidence").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertIdentificationHistorySchema = createInsertSchema(identificationHistory).pick({
  userId: true,
  imageUrl: true,
  results: true,
  confidence: true,
});

// Carbon Impact Tracking
export const carbonTracking = pgTable("carbon_tracking", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  totalPlants: integer("total_plants").notNull(),
  co2Absorbed: integer("co2_absorbed").notNull(), // in grams
  oxygenProduced: integer("oxygen_produced").notNull(), // in grams
  airPurified: integer("air_purified").notNull(), // in cubic meters
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertCarbonTrackingSchema = createInsertSchema(carbonTracking).pick({
  userId: true,
  totalPlants: true,
  co2Absorbed: true,
  oxygenProduced: true,
  airPurified: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Plant = typeof plants.$inferSelect;
export type InsertPlant = z.infer<typeof insertPlantSchema>;

export type UserPlant = typeof userPlants.$inferSelect;
export type InsertUserPlant = z.infer<typeof insertUserPlantSchema>;

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = z.infer<typeof insertCommunityPostSchema>;

export type IdentificationHistory = typeof identificationHistory.$inferSelect;
export type InsertIdentificationHistory = z.infer<typeof insertIdentificationHistorySchema>;

export type CarbonTracking = typeof carbonTracking.$inferSelect;
export type InsertCarbonTracking = z.infer<typeof insertCarbonTrackingSchema>;
