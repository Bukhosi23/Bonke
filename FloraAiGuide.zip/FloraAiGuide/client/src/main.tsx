import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Function to observe and animate elements when they come into view
function setupScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate-on-scroll");
        }
      });
    },
    { threshold: 0.1 }
  );

  // Observe all app-section elements
  setTimeout(() => {
    const sections = document.querySelectorAll(".app-section");
    sections.forEach((section) => {
      observer.observe(section);
    });
  }, 100);
}

// Render the app
createRoot(document.getElementById("root")!).render(<App />);

// Setup animations after rendering
window.addEventListener("load", setupScrollAnimations);
