import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Calculate carbon impact based on number of plants
export function calculateCarbonImpact(numberOfPlants: number, plantTypes: string[] = []) {
  // Average values for demonstration
  const avgCO2PerPlant = 0.4; // kg per year
  const avgOxygenPerPlant = 0.2; // kg per year
  const avgAirPurifiedPerPlant = 1.3; // cubic meters per day
  
  // Calculate totals
  const co2Absorbed = Math.round(numberOfPlants * avgCO2PerPlant * 1000); // Convert to grams
  const oxygenProduced = Math.round(numberOfPlants * avgOxygenPerPlant * 1000); // Convert to grams
  const airPurified = Math.round(numberOfPlants * avgAirPurifiedPerPlant * 10) / 10; // Round to 1 decimal
  
  return {
    totalPlants: numberOfPlants,
    co2Absorbed,
    oxygenProduced,
    airPurified,
    impactPercentage: Math.min(Math.round(numberOfPlants * 8), 100)
  };
}

// Format plant care frequency text
export function formatCareFrequency(frequency: string): string {
  if (!frequency) return "Not specified";
  
  // Format "Every X days/weeks" or descriptive text
  return frequency.charAt(0).toUpperCase() + frequency.slice(1);
}

// Get a background gradient based on care difficulty
export function getCareLevelColor(level: string): string {
  switch (level?.toLowerCase()) {
    case "easy":
      return "from-green-100 to-green-50";
    case "moderate":
      return "from-amber-100 to-amber-50";
    case "difficult":
      return "from-red-100 to-red-50";
    default:
      return "from-gray-100 to-gray-50";
  }
}

// Format number with commas for thousands
export function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Format date to relative time (e.g., "2 hours ago")
export function formatRelativeTime(dateString: string | Date): string {
  const date = typeof dateString === "string" ? new Date(dateString) : dateString;
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  if (diffSecs < 60) return `${diffSecs} seconds ago`;
  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays < 30) return `${diffDays} days ago`;
  
  return date.toLocaleDateString();
}
