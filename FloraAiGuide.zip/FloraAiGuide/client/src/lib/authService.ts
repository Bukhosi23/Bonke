// authService.ts
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithPopup,
  GoogleAuthProvider,
  OAuthProvider,
  signOut,
  updateProfile,
  User,
  UserCredential,
  Auth,
  onAuthStateChanged as firebaseOnAuthStateChanged
} from 'firebase/auth';
import { auth } from './firebaseConfig';

// Mock user for demo purposes when Firebase is not configured
const mockUser = {
  uid: 'mock-uid-123',
  email: 'demo@floraai.com',
  displayName: 'Demo User',
  photoURL: null,
  emailVerified: true,
  isAnonymous: false,
  metadata: {},
  providerData: [],
  refreshToken: '',
  tenantId: null,
  delete: async () => {},
  getIdToken: async () => 'mock-token',
  getIdTokenResult: async () => ({ token: 'mock-token', signInProvider: 'password', expirationTime: '', issuedAtTime: '', authTime: '', claims: {} }),
  reload: async () => {},
  toJSON: () => ({}),
  providerId: 'password',
  phoneNumber: null
} as unknown as User;

// Helper function to handle auth errors
const handleAuthError = (error: any): never => {
  // Extract the error message
  let errorMessage = 'Authentication failed';
  
  if (error.code) {
    switch (error.code) {
      case 'auth/email-already-in-use':
        errorMessage = 'This email is already registered';
        break;
      case 'auth/invalid-email':
        errorMessage = 'Invalid email format';
        break;
      case 'auth/weak-password':
        errorMessage = 'Password is too weak';
        break;
      case 'auth/user-not-found':
      case 'auth/wrong-password':
        errorMessage = 'Invalid email or password';
        break;
      case 'auth/too-many-requests':
        errorMessage = 'Too many failed attempts. Try again later';
        break;
      default:
        errorMessage = `Authentication error: ${error.message}`;
    }
  } else if (error.message) {
    errorMessage = error.message;
  }
  
  throw new Error(errorMessage);
};

// Local storage helper functions
const setUserPreference = (uid: string, data: Record<string, any>) => {
  try {
    localStorage.setItem(`user_${uid}`, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

const getUserPreference = (uid: string): Record<string, any> | null => {
  try {
    const data = localStorage.getItem(`user_${uid}`);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Error reading from localStorage:', error);
    return null;
  }
};

// 1. Email/Password Authentication
export const registerWithEmail = async (
  email: string, 
  password: string, 
  username: string
): Promise<User> => {
  try {
    // Client-side validation
    if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(email)) {
      throw new Error('Invalid email format');
    }

    if (password.length < 8) {
      throw new Error('Password must be at least 8 characters');
    }

    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network request
      // Return mock user in demo mode
      return { ...mockUser, email, displayName: username };
    }

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    // Add username to profile
    await updateProfile(userCredential.user, {
      displayName: username
    });

    // Set initial preferences
    setUserPreference(userCredential.user.uid, {
      theme: 'light',
      notificationEnabled: true,
      preferredAuthMethod: 'email'
    });

    return userCredential.user;
  } catch (error) {
    return handleAuthError(error);
  }
};

export const loginWithEmail = async (email: string, password: string): Promise<User> => {
  try {
    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network request
      // Return mock user in demo mode
      return { ...mockUser, email };
    }

    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    return handleAuthError(error);
  }
};

export const resetPassword = async (email: string): Promise<void> => {
  try {
    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network request
      return;
    }

    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    handleAuthError(error);
  }
};

// 2. Social Logins
export const signInWithGoogle = async (): Promise<User> => {
  try {
    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network request
      // Return mock user in demo mode with Google provider
      return {
        ...mockUser,
        displayName: 'Google User',
        providerId: 'google.com'
      };
    }

    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    return handleAuthError(error);
  }
};

export const signInWithApple = async (): Promise<User> => {
  try {
    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network request
      // Return mock user in demo mode with Apple provider
      return {
        ...mockUser,
        displayName: 'Apple User',
        providerId: 'apple.com'
      };
    }

    const provider = new OAuthProvider('apple.com');
    provider.addScope('email');
    provider.addScope('name');

    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    return handleAuthError(error);
  }
};

// 3. Sign out
export const logOut = async (): Promise<void> => {
  try {
    // Check if Firebase auth is available
    if (!auth) {
      console.warn('Firebase auth not available, using mock implementation');
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network request
      return;
    }

    await signOut(auth);
  } catch (error) {
    console.error('Sign out error:', error);
    throw error;
  }
};

// 4. Get current user
export const getCurrentUser = (): User | null => {
  if (!auth) {
    console.warn('Firebase auth not available, using mock implementation');
    return null;
  }
  return auth.currentUser;
};

// 5. Auth state observer
export const onAuthStateChanged = (callback: (user: User | null) => void) => {
  if (!auth) {
    console.warn('Firebase auth not available, using mock implementation');
    // Simulate auth state change after a delay
    setTimeout(() => callback(null), 500);
    return () => {};
  }
  return firebaseOnAuthStateChanged(auth, callback);
};