import { motion } from "framer-motion";

// Animation presets for leaf unfolding
export const leafUnfurlAnimation = {
  initial: { scale: 0.8, rotate: -5, opacity: 0 },
  animate: { scale: 1, rotate: 0, opacity: 1 },
  transition: { duration: 0.8, ease: "easeOut" }
};

// Fade in animation
export const fadeInAnimation = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { duration: 0.6, ease: "easeIn" }
};

// Slide up animation
export const slideUpAnimation = {
  initial: { y: 20, opacity: 0 },
  animate: { y: 0, opacity: 1 },
  transition: { duration: 0.6, ease: "easeOut" }
};

// Staggered children animation
export const staggeredContainer = {
  initial: {},
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

// Pulse animation
export const pulseAnimation = {
  initial: { scale: 1 },
  animate: {
    scale: [1, 1.05, 1],
    transition: {
      duration: 3,
      repeat: Infinity,
      repeatType: "reverse",
      ease: "easeInOut"
    }
  }
};

// Floating animation
export const floatingAnimation = {
  initial: { y: 0 },
  animate: {
    y: [0, -10, 0],
    transition: {
      duration: 3,
      repeat: Infinity,
      repeatType: "reverse",
      ease: "easeInOut"
    }
  }
};

// Hover animation for plant buttons
export const plantButtonHoverAnimation = {
  whileHover: {
    y: -2,
    transition: { duration: 0.3 }
  },
  whileTap: {
    scale: 0.98,
    transition: { duration: 0.2 }
  }
};

// Card hover animation
export const organicCardHoverAnimation = {
  whileHover: {
    y: -5,
    boxShadow: "0 15px 30px rgba(0,0,0,0.1)",
    transition: { duration: 0.3 }
  }
};

// The shimmer effect for plant identification loading state
export const shimmerAnimation = {
  initial: { backgroundPosition: "-200% 0" },
  animate: {
    backgroundPosition: ["200% 0", "-200% 0"],
    transition: {
      repeat: Infinity,
      duration: 1.5,
      ease: "linear"
    }
  }
};

// Plant growing animation for AR visualization
export const plantGrowthAnimation = {
  initial: { scaleY: 0, opacity: 0, y: 50 },
  animate: { 
    scaleY: 1, 
    opacity: 1, 
    y: 0,
    transition: { 
      duration: 2.5, 
      ease: [0.34, 1.56, 0.64, 1] // Custom spring-like effect
    }
  }
};
