// Example plant data for demonstrations

export interface PlantIdentificationResult {
  plantId: number;
  commonName: string;
  scientificName: string;
  confidence: number;
  matches: {
    plantId: number;
    name: string;
    confidence: number;
  }[];
}

export const exampleIdentificationResults: PlantIdentificationResult = {
  plantId: 1,
  commonName: "Monstera Deliciosa",
  scientificName: "Monstera deliciosa",
  confidence: 98,
  matches: [
    {
      plantId: 1,
      name: "Monstera Deliciosa",
      confidence: 98
    },
    {
      plantId: 2,
      name: "Rhaphidophora Tetrasperma",
      confidence: 65
    },
    {
      plantId: 3,
      name: "Philodendron Bipinnatifidum",
      confidence: 52
    }
  ]
};

export const examplePlantCareData = {
  water: {
    frequency: "Water weekly",
    description: "Allow soil to dry out between waterings",
    icon: "droplet"
  },
  light: {
    level: "Indirect light",
    description: "Bright, indirect light is ideal",
    icon: "sun"
  },
  temperature: {
    range: "65-85°F",
    description: "Prefers warm temperatures",
    icon: "thermometer"
  },
  humidity: {
    level: "Medium to high",
    description: "Enjoys humid environments",
    icon: "droplets"
  },
  fertilizer: {
    frequency: "Monthly in growing season",
    description: "Use balanced liquid fertilizer",
    icon: "flask"
  },
  soil: {
    type: "Well-draining mix",
    description: "Mix with perlite for aeration",
    icon: "layers"
  }
};

export const examplePlantImages = [
  "https://images.unsplash.com/photo-1614594975525-e45190c55d0b",
  "https://images.unsplash.com/photo-1509423350716-97f9360b4e09",
  "https://images.unsplash.com/photo-1597055181900-23778533afd9",
  "https://images.unsplash.com/photo-1558693168-c370615b54e0",
  "https://images.unsplash.com/photo-1520412099551-62b6bafeb5bb",
  "https://images.unsplash.com/photo-1463936575829-25148e1db1b8"
];

export const exampleUsers = [
  {
    id: 1,
    username: "plant_lover",
    displayName: "Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80"
  },
  {
    id: 2,
    username: "green_thumb",
    displayName: "David Chen",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e"
  },
  {
    id: 3,
    username: "urban_gardener",
    displayName: "Emma Rodriguez",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956"
  }
];

export const exampleCommunityPosts = [
  {
    id: 1,
    userId: 1,
    title: "My monstera has three new leaves this month!",
    content: "What's your secret for fast growth? #PlantProgress",
    imageUrl: "https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e",
    likes: 24,
    createdAt: new Date(Date.now() - 7200000) // 2 hours ago
  },
  {
    id: 2,
    userId: 2,
    title: "Help! What's wrong with my fiddle leaf fig?",
    content: "The leaves are turning brown at the edges. Any advice would be appreciated!",
    imageUrl: "https://images.unsplash.com/photo-1599009944997-3544f382d585",
    likes: 15,
    createdAt: new Date(Date.now() - 86400000) // 1 day ago
  },
  {
    id: 3,
    userId: 3,
    title: "My new plant corner setup",
    content: "Finally created the perfect space for my plant babies! #PlantCorner",
    imageUrl: "https://images.unsplash.com/photo-1547146092-983100b1b4fd",
    likes: 42,
    createdAt: new Date(Date.now() - 259200000) // 3 days ago
  }
];

export const exampleCarbonData = {
  totalPlants: 8,
  co2Absorbed: 3200, // grams per year
  oxygenProduced: 1800, // grams per year
  airPurified: 10.5, // cubic meters per day
  impactPercentage: 65
};
