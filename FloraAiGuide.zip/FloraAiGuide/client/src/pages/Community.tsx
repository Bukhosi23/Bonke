import { useEffect } from 'react';
import { motion } from 'framer-motion';
import CommunitySection from '@/components/community/CommunitySection';

const Community = () => {
  // Add meta tags for SEO
  useEffect(() => {
    document.title = "Plant Community - FloraAI";
  }, []);

  // Function to observe and animate elements when they come into view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-on-scroll");
          }
        });
      },
      { threshold: 0.1 }
    );

    // Observe all app-section elements
    const sections = document.querySelectorAll(".app-section");
    sections.forEach((section) => {
      observer.observe(section);
    });

    // Cleanup function
    return () => {
      sections.forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, []);

  return (
    <div className="min-h-screen">
      <div className="bg-[hsl(var(--moss-green-light))/10] py-12">
        <div className="max-w-5xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl font-bold text-[hsl(var(--moss-green-dark))] mb-4">
              Plant Community
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Share your plant journey, get advice, and connect with fellow plant enthusiasts.
              Learn from each other and grow together in our vibrant community.
            </p>
          </motion.div>
        </div>
      </div>

      <CommunitySection />
      
      <div className="max-w-5xl mx-auto px-4 my-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid md:grid-cols-2 gap-16 items-center"
        >
          <div>
            <img 
              src="https://images.unsplash.com/photo-1547146092-983100b1b4fd" 
              alt="Community garden event" 
              className="rounded-3xl shadow-lg"
            />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-[hsl(var(--moss-green-dark))] mb-4">
              Join Community Events
            </h2>
            <p className="text-gray-600 mb-6">
              Connect with local plant enthusiasts through virtual and in-person events, workshops, 
              and plant swaps organized by the FloraAI community.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                  </svg>
                </div>
                <div className="ml-3">
                  <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Plant Swap Saturdays</h4>
                  <p className="text-sm text-gray-600">Monthly virtual gatherings to trade plants and cuttings</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M15 3a6 6 0 0 1 6 6m-6-6a6 6 0 0 0-6 6m6-6v6m0 0h6"></path>
                    <path d="M16 7h.01"></path>
                    <path d="M5 8a4 4 0 1 0 8 0A4 4 0 0 0 5 8"></path>
                    <path d="M3 21a11 11 0 0 1 18 0"></path>
                  </svg>
                </div>
                <div className="ml-3">
                  <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Expert Workshops</h4>
                  <p className="text-sm text-gray-600">Learn specialized techniques from professional botanists</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M16 12h-6.5a2 2 0 1 0 0 4h1a2 2 0 1 1 0 4H8"></path>
                    <path d="M12 6v2"></path>
                    <path d="M12 16v2"></path>
                  </svg>
                </div>
                <div className="ml-3">
                  <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Sustainable Gardening</h4>
                  <p className="text-sm text-gray-600">Community initiatives focused on environmental impact</p>
                </div>
              </div>
            </div>
            
            <motion.button
              className="mt-8 bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))] text-white font-medium py-3 px-8 rounded-full transition-colors duration-300"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              Browse Events
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Community;
