import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { leafUnfurlAnimation, fadeInAnimation } from '@/lib/animations';
import CarbonTrackerComponent from '@/components/carbon/CarbonTracker';
import { exampleCarbonData } from '@/lib/plantData';
import { useQuery } from '@tanstack/react-query';

export default function CarbonTrackerPage() {
  const [userId, setUserId] = useState<number | undefined>(1); // For demo purposes
  
  // In a real app, this would come from authentication
  useEffect(() => {
    // Simulate user login
    setUserId(1);
  }, []);
  
  // Fetch carbon tracking data
  const { data: carbonData, isLoading } = useQuery({
    queryKey: ['/api/carbon-tracking', userId],
    queryFn: async () => {
      if (!userId) return exampleCarbonData;
      return exampleCarbonData; // In a real app, this would fetch from API
    },
    enabled: !!userId,
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div 
        className="text-center mb-12"
        {...fadeInAnimation}
      >
        <h1 className="text-4xl font-bold text-[hsl(var(--moss-green-dark))] mb-3">Carbon Impact Tracker</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Monitor your plants' contribution to a healthier planet. Every plant you grow helps combat climate change.
        </p>
      </motion.div>
      
      <motion.div
        className="max-w-4xl mx-auto bg-white shadow-lg rounded-xl overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        {isLoading ? (
          <div className="h-96 flex items-center justify-center">
            <div className="w-12 h-12 border-4 border-[hsl(var(--moss-green))] border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <CarbonTrackerComponent 
            userId={userId} 
            initialData={carbonData || exampleCarbonData}
          />
        )}
      </motion.div>
      
      <motion.div 
        className="mt-16 bg-[hsl(var(--moss-green-light))/10] rounded-xl p-8 max-w-4xl mx-auto"
        {...leafUnfurlAnimation}
      >
        <h2 className="text-2xl font-bold text-[hsl(var(--moss-green-dark))] mb-4">How It Works</h2>
        <p className="text-gray-700 mb-6">
          Our carbon impact calculator uses scientific data to estimate how much CO₂ your plants absorb and oxygen they produce.
          Each plant species has a different environmental impact based on its size, type, and growth conditions.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-[hsl(var(--moss-green))/20] rounded-full flex items-center justify-center mb-4">
              <span className="text-xl">🌱</span>
            </div>
            <h3 className="font-medium text-[hsl(var(--moss-green-dark))] mb-2">Track Your Plants</h3>
            <p className="text-sm text-gray-600">Add each plant to your collection and see your environmental impact grow over time.</p>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-[hsl(var(--moss-green))/20] rounded-full flex items-center justify-center mb-4">
              <span className="text-xl">📊</span>
            </div>
            <h3 className="font-medium text-[hsl(var(--moss-green-dark))] mb-2">Measure Impact</h3>
            <p className="text-sm text-gray-600">See real metrics of CO₂ absorbed and oxygen produced by your green companions.</p>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-[hsl(var(--moss-green))/20] rounded-full flex items-center justify-center mb-4">
              <span className="text-xl">🏆</span>
            </div>
            <h3 className="font-medium text-[hsl(var(--moss-green-dark))] mb-2">Set Goals</h3>
            <p className="text-sm text-gray-600">Work toward environmental targets and earn badges for your positive impact.</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}