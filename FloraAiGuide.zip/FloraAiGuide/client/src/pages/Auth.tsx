import { useState } from 'react';
import { motion } from 'framer-motion';
import { useLocation } from 'wouter';
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import ForgotPasswordForm from '@/components/auth/ForgotPasswordForm';
import { useAuth } from '@/contexts/AuthContext';

type AuthView = 'login' | 'register' | 'forgot-password';

export default function Auth() {
  const [, setLocation] = useLocation();
  const [view, setView] = useState<AuthView>('login');
  const { currentUser } = useAuth();
  
  // If user is already logged in, redirect to home
  if (currentUser) {
    setLocation('/');
    return null;
  }

  const handleAuthSuccess = () => {
    setLocation('/');
  };

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-b from-gray-900 to-gray-800">
      {/* Floating leaves animation in background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(10)].map((_, index) => (
          <motion.div
            key={index}
            className="absolute w-16 h-16 opacity-10"
            style={{
              left: `${Math.random() * 100}%`,
              top: `-5%`,
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2348BB78'%3E%3Cpath d='M6.5 20Q4.22 20 2.61 18.43 1 16.85 1 14.58 1 12.63 2.17 11.1 3.35 9.57 5.25 9.15 5.88 6.85 7.75 5.43 9.63 4 12 4 14.93 4 16.96 6.04 19 8.07 19 11 20.73 11.2 21.86 12.5 23 13.78 23 15.5 23 17.38 21.69 18.69 20.38 20 18.5 20H6.5Z'/%3E%3C/svg%3E")`,
              backgroundSize: 'contain',
              backgroundRepeat: 'no-repeat',
              transform: 'rotate(0deg)'
            }}
            animate={{
              y: window.innerHeight,
              rotate: 360,
              opacity: [0.1, 0.3, 0.1]
            }}
            transition={{
              duration: 15 + Math.random() * 10,
              repeat: Infinity,
              ease: "linear"
            }}
          />
        ))}
      </div>
      
      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <img
          className="mx-auto h-20 w-auto"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2348BB78'%3E%3Cpath d='M12 22q-4.025 0-7.013-2.425T2 13.175q0-3.9 3.688-8.4Q9.375 1 12 1q2.625 0 6.313 3.775Q22 8.55 22 13.15q0 3.875-2.988 6.3T12 22Z'/%3E%3C/svg%3E"
          alt="FloraAI Logo"
        />
        <h2 className="mt-3 text-center text-3xl font-extrabold text-green-500">
          FloraAI
        </h2>
        <p className="mt-2 text-center text-sm text-gray-400">
          Your plant companion for a greener world
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <motion.div
          key={view}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          {view === 'login' && (
            <LoginForm 
              onSuccess={handleAuthSuccess} 
              onForgotPassword={() => setView('forgot-password')}
              onRegisterClick={() => setView('register')}
            />
          )}
          
          {view === 'register' && (
            <RegisterForm
              onSuccess={handleAuthSuccess}
              onLoginClick={() => setView('login')}
            />
          )}
          
          {view === 'forgot-password' && (
            <ForgotPasswordForm
              onBackToLogin={() => setView('login')}
            />
          )}
        </motion.div>
      </div>
    </div>
  );
}