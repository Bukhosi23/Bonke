import { useEffect } from 'react';
import EnhancedHeroSection from '@/components/home/EnhancedHeroSection';
import FeaturesSection from '@/components/home/FeaturesSection';
import InteractiveDemo from '@/components/home/InteractiveDemo';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import DownloadSection from '@/components/home/DownloadSection';

const Home = () => {
  // Add meta tags for SEO
  useEffect(() => {
    document.title = "FloraAI - Plant Identification & Care App";
    
    // Add meta description for SEO
    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = 'FloraAI is an AI-powered plant identification and care app with personalized care plans, AR time travel, and carbon tracking features.';
    document.head.appendChild(metaDescription);
    
    // Add Open Graph tags for better social sharing
    const ogTitle = document.createElement('meta');
    ogTitle.property = 'og:title';
    ogTitle.content = 'FloraAI - The Smart Plant Companion';
    document.head.appendChild(ogTitle);
    
    const ogDescription = document.createElement('meta');
    ogDescription.property = 'og:description';
    ogDescription.content = 'Identify plants, get personalized care plans, and track your environmental impact with our AI-powered plant companion.';
    document.head.appendChild(ogDescription);
    
    // Clean up function
    return () => {
      document.head.removeChild(metaDescription);
      document.head.removeChild(ogTitle);
      document.head.removeChild(ogDescription);
    };
  }, []);

  // Function to observe and animate elements when they come into view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-on-scroll");
          }
        });
      },
      { threshold: 0.1 }
    );

    // Observe all app-section elements
    const sections = document.querySelectorAll(".app-section");
    sections.forEach((section) => {
      observer.observe(section);
    });

    // Cleanup function
    return () => {
      sections.forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, []);
  
  return (
    <div className="min-h-screen">
      <EnhancedHeroSection />
      <FeaturesSection />
      <InteractiveDemo />
      <TestimonialsSection />
      <DownloadSection />
    </div>
  );
};

export default Home;
