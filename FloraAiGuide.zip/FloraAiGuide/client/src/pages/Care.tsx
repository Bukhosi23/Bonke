import { useEffect } from 'react';
import { motion } from 'framer-motion';
import CarePlans from '@/components/care/CarePlans';

const Care = () => {
  // Add meta tags for SEO
  useEffect(() => {
    document.title = "Plant Care Plans - FloraAI";
  }, []);

  // Function to observe and animate elements when they come into view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-on-scroll");
          }
        });
      },
      { threshold: 0.1 }
    );

    // Observe all app-section elements
    const sections = document.querySelectorAll(".app-section");
    sections.forEach((section) => {
      observer.observe(section);
    });

    // Cleanup function
    return () => {
      sections.forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, []);

  return (
    <div className="min-h-screen">
      <div className="bg-[hsl(var(--moss-green-light))/10] py-12">
        <div className="max-w-5xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl font-bold text-[hsl(var(--moss-green-dark))] mb-4">
              Personalized Care Plans
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Get customized care recommendations based on your specific plants, location, and home environment.
              Our AI-driven care plans ensure your plants thrive year-round.
            </p>
          </motion.div>
        </div>
      </div>

      <CarePlans />
      
      <div className="max-w-5xl mx-auto px-4 my-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-[hsl(var(--moss-green-light))/5] rounded-3xl p-8"
        >
          <h2 className="text-2xl font-bold text-[hsl(var(--moss-green-dark))] mb-6 text-center">
            Why Personalized Care Matters
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2v8"></path>
                  <path d="M4.93 10.93l1.41 1.41"></path>
                  <path d="M2 18h2"></path>
                  <path d="M20 18h2"></path>
                  <path d="M19.07 10.93l-1.41 1.41"></path>
                  <path d="M22 22H2"></path>
                  <path d="M16 8s-1.5 2-4 2-4-2-4-2"></path>
                  <path d="M12 12v3"></path>
                  <path d="M12 17v2"></path>
                </svg>
              </div>
              <h3 className="font-medium text-[hsl(var(--moss-green-dark))] text-lg mb-2">Unique Needs</h3>
              <p className="text-gray-600">
                Each plant species has specific requirements for water, light, humidity, and nutrients
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                  <path d="M2 17l10 5 10-5"></path>
                  <path d="M2 12l10 5 10-5"></path>
                </svg>
              </div>
              <h3 className="font-medium text-[hsl(var(--moss-green-dark))] text-lg mb-2">Environment Matters</h3>
              <p className="text-gray-600">
                Your home's temperature, humidity, and light conditions affect plant health differently
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M16 10h-4l-1 6h4"></path>
                  <path d="M12 7v2"></path>
                </svg>
              </div>
              <h3 className="font-medium text-[hsl(var(--moss-green-dark))] text-lg mb-2">Seasonal Changes</h3>
              <p className="text-gray-600">
                Care needs shift throughout the year as seasons, growth phases, and daylight hours change
              </p>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <p className="text-gray-600 mb-6 max-w-3xl mx-auto">
              FloraAI analyzes your plants and environment to create tailored care plans that adapt over time,
              helping your plants not just survive, but truly thrive.
            </p>
            
            <motion.button
              className="bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))] text-white font-medium py-3 px-8 rounded-full transition-colors duration-300"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              Create Your Care Plan
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Care;
