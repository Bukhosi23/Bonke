import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import MobileMenu from './MobileMenu';
import { useAuth } from '@/contexts/AuthContext';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location, setLocation] = useLocation();
  const { currentUser, logout } = useAuth();

  // Handle scroll event to add shadow to header when scrolled
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when location changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const handleLogout = async () => {
    await logout();
    setLocation('/');
  };

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!currentUser || !currentUser.displayName) return 'FI';
    const names = currentUser.displayName.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };

  return (
    <header className="relative z-50">
      <nav className={cn(
        "bg-white transition-shadow duration-300",
        isScrolled ? "shadow-md" : "shadow-sm"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <Link href="/" className="flex-shrink-0 flex items-center">
                <span className="text-[hsl(var(--moss-green-dark))] text-2xl font-bold">
                  Flora<span className="text-[hsl(var(--sunbeam-yellow))]">AI</span>
                </span>
              </Link>
              <div className="hidden md:ml-10 md:flex md:space-x-8">
                <Link href="/identify" className={cn(
                  "plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium",
                  location === "/identify" && "text-[hsl(var(--moss-green))] font-semibold"
                )}>
                  Identify
                </Link>
                <Link href="/care" className={cn(
                  "plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium",
                  location === "/care" && "text-[hsl(var(--moss-green))] font-semibold"
                )}>
                  Care Plans
                </Link>
                <Link href="/community" className={cn(
                  "plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium",
                  location === "/community" && "text-[hsl(var(--moss-green))] font-semibold"
                )}>
                  Community
                </Link>
                <Link href="/ar-time-travel" className={cn(
                  "plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium",
                  location === "/ar-time-travel" && "text-[hsl(var(--moss-green))] font-semibold"
                )}>
                  AR Time Travel
                </Link>
                <Link href="/carbon-tracker" className={cn(
                  "plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium",
                  location === "/carbon-tracker" && "text-[hsl(var(--moss-green))] font-semibold"
                )}>
                  Carbon Tracker
                </Link>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {currentUser ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center space-x-2 focus:outline-none">
                      <Avatar className="h-10 w-10 bg-[hsl(var(--moss-green))] text-white cursor-pointer hover:opacity-90 transition-opacity">
                        <AvatarFallback>{getUserInitials()}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-medium text-[hsl(var(--moss-green-dark))] hidden md:inline-block">
                        {currentUser.displayName || 'User'}
                      </span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-2 py-1.5">
                      <p className="text-sm font-medium">{currentUser.displayName || 'User'}</p>
                      <p className="text-xs text-gray-500 truncate">{currentUser.email}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/profile" className="cursor-pointer">
                        My Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/my-plants" className="cursor-pointer">
                        My Plants
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/carbon-tracker" className="cursor-pointer">
                        Carbon Impact
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="text-red-500 cursor-pointer"
                      onClick={handleLogout}
                    >
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <>
                  <Link href="/auth" className="text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium hidden md:inline-block">
                    Log in
                  </Link>
                  <Link href="/auth" className="plant-button inline-flex items-center px-6 py-2.5 bg-[hsl(var(--moss-green))] text-white font-medium rounded-full shadow-md hover:bg-[hsl(var(--moss-green-light))] transition duration-300 ease-in-out">
                    Get Started
                  </Link>
                </>
              )}
              <button 
                className="md:hidden text-[hsl(var(--moss-green-dark))]"
                onClick={() => setIsMenuOpen(true)}
                aria-label="Open menu"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>
      
      {/* Mobile menu */}
      <MobileMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
    </header>
  );
};

export default Header;
