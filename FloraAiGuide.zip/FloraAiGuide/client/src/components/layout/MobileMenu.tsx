import { Link, useLocation } from 'wouter';
import { useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  const [, setLocation] = useLocation();
  const { currentUser, logout } = useAuth();

  // Prevent body scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!currentUser || !currentUser.displayName) return 'FI';
    const names = currentUser.displayName.split(' ');
    if (names.length === 1) return names[0].charAt(0).toUpperCase();
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };

  const handleLogout = async () => {
    await logout();
    onClose();
    setLocation('/');
  };

  return (
    <div 
      className={cn(
        "mobile-menu fixed top-0 right-0 w-3/4 h-full bg-white shadow-xl z-50 p-6",
        isOpen ? "open" : ""
      )}
    >
      <div className="flex justify-between items-center mb-8">
        <span className="text-[hsl(var(--moss-green-dark))] text-2xl font-bold">
          Flora<span className="text-[hsl(var(--sunbeam-yellow))]">AI</span>
        </span>
        <button 
          onClick={onClose}
          className="text-[hsl(var(--moss-green-dark))] text-2xl"
          aria-label="Close menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      
      {currentUser && (
        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-2">
            <Avatar className="h-10 w-10 bg-[hsl(var(--moss-green))] text-white">
              <AvatarFallback>{getUserInitials()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-[hsl(var(--moss-green-dark))]">
                {currentUser.displayName || 'User'}
              </p>
              <p className="text-xs text-gray-500 truncate max-w-[180px]">
                {currentUser.email}
              </p>
            </div>
          </div>
          <Separator className="my-3" />
        </div>
      )}
      
      <div className="flex flex-col space-y-4">
        <Link 
          href="/identify" 
          className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
          onClick={onClose}
        >
          Identify
        </Link>
        <Link 
          href="/care" 
          className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
          onClick={onClose}
        >
          Care Plans
        </Link>
        <Link 
          href="/community" 
          className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
          onClick={onClose}
        >
          Community
        </Link>
        <Link 
          href="/ar-time-travel" 
          className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
          onClick={onClose}
        >
          AR Time Travel
        </Link>
        <Link 
          href="/carbon-tracker" 
          className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
          onClick={onClose}
        >
          Carbon Tracker
        </Link>
        
        {currentUser ? (
          <>
            <Separator className="my-2" />
            
            <Link 
              href="/profile" 
              className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
              onClick={onClose}
            >
              My Profile
            </Link>
            
            <Link 
              href="/my-plants" 
              className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
              onClick={onClose}
            >
              My Plants
            </Link>
            
            <button 
              onClick={handleLogout}
              className="plant-button text-left text-red-500 hover:text-red-600 font-medium p-3 rounded-lg hover:bg-gray-50"
            >
              Log Out
            </button>
          </>
        ) : (
          <>
            <Separator className="my-2" />
            
            <Link 
              href="/auth" 
              className="plant-button text-[hsl(var(--moss-green-dark))] hover:text-[hsl(var(--moss-green))] font-medium p-3 rounded-lg hover:bg-gray-50"
              onClick={onClose}
            >
              Log In
            </Link>
            
            <Link 
              href="/auth" 
              className="plant-button mt-4 w-full inline-flex justify-center items-center px-6 py-3 bg-[hsl(var(--moss-green))] text-white font-medium rounded-full shadow-md hover:bg-[hsl(var(--moss-green-light))] transition duration-300 ease-in-out"
              onClick={onClose}
            >
              Get Started
            </Link>
          </>
        )}
      </div>
      
      {/* Overlay for clicking outside to close */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40" 
          onClick={onClose}
          aria-hidden="true"
        />
      )}
    </div>
  );
};

export default MobileMenu;
