import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FcGoogle } from 'react-icons/fc';
import { SiApple } from 'react-icons/si';
import { useAuth } from '@/contexts/AuthContext';

// Form schema
const registerSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  confirmPassword: z.string()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type RegisterFormValues = z.infer<typeof registerSchema>;

interface RegisterFormProps {
  onSuccess?: () => void;
  onLoginClick: () => void;
}

export default function RegisterForm({ onSuccess, onLoginClick }: RegisterFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { register: registerUser, loginWithGoogle, loginWithApple } = useAuth();
  
  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  const onSubmit = async (data: RegisterFormValues) => {
    try {
      setIsSubmitting(true);
      const user = await registerUser(data.email, data.password, data.username);
      if (user && onSuccess) {
        onSuccess();
      }
    } catch (error) {
      // Error handling is done in the AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setIsSubmitting(true);
      const user = await loginWithGoogle();
      if (user && onSuccess) {
        onSuccess();
      }
    } catch (error) {
      // Error handling is done in the AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      setIsSubmitting(true);
      const user = await loginWithApple();
      if (user && onSuccess) {
        onSuccess();
      }
    } catch (error) {
      // Error handling is done in the AuthContext
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-md p-8 space-y-8 bg-white/5 backdrop-blur-lg rounded-2xl shadow-xl">
      <div className="text-center">
        <h2 className="mt-6 text-3xl font-bold text-green-500">Join FloraAI</h2>
        <p className="mt-2 text-sm text-gray-300">Create an account to start your plant journey</p>
      </div>
      
      <form onSubmit={form.handleSubmit(onSubmit)} className="mt-8 space-y-6">
        <div className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-200">
              Username
            </label>
            <input
              id="username"
              type="text"
              {...form.register('username')}
              className="mt-1 block w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800/50 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
              placeholder="plantlover"
            />
            {form.formState.errors.username && (
              <p className="mt-1 text-sm text-red-500">{form.formState.errors.username.message}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-200">
              Email
            </label>
            <input
              id="email"
              type="email"
              {...form.register('email')}
              className="mt-1 block w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800/50 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
              placeholder="you@example.com"
            />
            {form.formState.errors.email && (
              <p className="mt-1 text-sm text-red-500">{form.formState.errors.email.message}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-200">
              Password
            </label>
            <input
              id="password"
              type="password"
              {...form.register('password')}
              className="mt-1 block w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800/50 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
              placeholder="••••••••"
            />
            {form.formState.errors.password && (
              <p className="mt-1 text-sm text-red-500">{form.formState.errors.password.message}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-200">
              Confirm Password
            </label>
            <input
              id="confirmPassword"
              type="password"
              {...form.register('confirmPassword')}
              className="mt-1 block w-full px-3 py-2 border border-gray-700 rounded-md bg-gray-800/50 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
              placeholder="••••••••"
            />
            {form.formState.errors.confirmPassword && (
              <p className="mt-1 text-sm text-red-500">{form.formState.errors.confirmPassword.message}</p>
            )}
          </div>
        </div>

        <div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Creating account...' : 'Create Account'}
          </button>
        </div>
      </form>
      
      <div className="mt-6">
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-700"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-gray-900 text-gray-400">Or continue with</span>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isSubmitting}
            className="w-full flex justify-center items-center py-2 px-4 border border-gray-700 rounded-md shadow-sm bg-white text-sm font-medium text-gray-800 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <FcGoogle className="h-5 w-5 mr-2" />
            Google
          </button>
          <button
            type="button"
            onClick={handleAppleLogin}
            disabled={isSubmitting}
            className="w-full flex justify-center items-center py-2 px-4 border border-gray-700 rounded-md shadow-sm bg-black text-sm font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <SiApple className="h-5 w-5 mr-2" />
            Apple
          </button>
        </div>
      </div>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-gray-400">
          Already have an account?{' '}
          <button 
            type="button"
            onClick={onLoginClick}
            className="font-medium text-green-500 hover:text-green-400 focus:outline-none focus:underline"
          >
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
}