import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { examplePlantCareData } from '@/lib/plantData';
import { staggeredContainer, leafUnfurlAnimation } from '@/lib/animations';

const popularPlants = [
  {
    id: 1,
    name: "Monstera Deliciosa",
    difficulty: "moderate",
    image: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=600&h=600"
  },
  {
    id: 2,
    name: "Snake Plant",
    difficulty: "easy",
    image: "https://images.unsplash.com/photo-1593482892290-f54227b4699b?auto=format&fit=crop&w=600&h=600"
  },
  {
    id: 3,
    name: "Fiddle Leaf Fig",
    difficulty: "difficult",
    image: "https://images.unsplash.com/photo-1597055181900-23778533afd9?auto=format&fit=crop&w=600&h=600"
  },
  {
    id: 4,
    name: "Peace Lily",
    difficulty: "easy",
    image: "https://images.unsplash.com/photo-1593482892385-f3e6f7731494?auto=format&fit=crop&w=600&h=600"
  }
];

const difficultyColors = {
  easy: "bg-green-100 text-green-800",
  moderate: "bg-amber-100 text-amber-800",
  difficult: "bg-red-100 text-red-800"
};

const weeklySchedule = [
  { day: "Monday", tasks: [] },
  { day: "Tuesday", tasks: ["Water Monstera", "Mist Ferns"] },
  { day: "Wednesday", tasks: [] },
  { day: "Thursday", tasks: ["Check soil moisture", "Rotate Plants"] },
  { day: "Friday", tasks: ["Water Snake Plant"] },
  { day: "Saturday", tasks: [] },
  { day: "Sunday", tasks: ["Water all plants", "Apply fertilizer"] }
];

interface CareGuideProps {
  plantName: string;
  onClose: () => void;
}

const CareGuide = ({ plantName, onClose }: CareGuideProps) => {
  return (
    <Card className="organic-card w-full">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[hsl(var(--moss-green-dark))]">{plantName} Care Guide</h3>
          <Button 
            variant="ghost" 
            className="h-8 w-8 p-0 rounded-full"
            onClick={onClose}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </Button>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <img 
              src={popularPlants.find(plant => plant.name === plantName)?.image} 
              alt={plantName} 
              className="w-full h-56 object-cover rounded-xl mb-4"
            />
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-gray-700">Care Difficulty:</h4>
                <span className={cn(
                  "px-2 py-1 rounded-full text-xs font-medium",
                  difficultyColors[popularPlants.find(plant => plant.name === plantName)?.difficulty || "moderate"]
                )}>
                  {popularPlants.find(plant => plant.name === plantName)?.difficulty || "moderate"}
                </span>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700 mb-2">Description:</h4>
                <p className="text-sm text-gray-600">
                  The {plantName} is a popular houseplant known for its distinctive features and air-purifying qualities.
                  It thrives in indoor environments and can live for many years with proper care.
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-5">
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-[hsl(var(--sky-blue))/20] flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sky-blue))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2v6"></path>
                  <path d="M5 10l7-6 7 6"></path>
                  <path d="M5 22v-8.3a4 4 0 0 1 .6-2.12l3.7-5.55"></path>
                  <path d="M19 22v-8.3a4 4 0 0 0-.6-2.12l-3.7-5.55"></path>
                  <line x1="9" y1="16" x2="9.01" y2="16"></line>
                  <line x1="15" y1="16" x2="15.01" y2="16"></line>
                  <path d="M9 19h6"></path>
                </svg>
              </div>
              <div className="ml-3">
                <h4 className="font-medium text-gray-800">Water</h4>
                <p className="text-sm text-gray-600">{examplePlantCareData.water.description}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-[hsl(var(--sunbeam-yellow))/20] flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="5"></circle>
                  <line x1="12" y1="1" x2="12" y2="3"></line>
                  <line x1="12" y1="21" x2="12" y2="23"></line>
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                  <line x1="1" y1="12" x2="3" y2="12"></line>
                  <line x1="21" y1="12" x2="23" y2="12"></line>
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                </svg>
              </div>
              <div className="ml-3">
                <h4 className="font-medium text-gray-800">Light</h4>
                <p className="text-sm text-gray-600">{examplePlantCareData.light.description}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-[hsl(var(--earth-brown))/20] flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--earth-brown))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path>
                </svg>
              </div>
              <div className="ml-3">
                <h4 className="font-medium text-gray-800">Temperature</h4>
                <p className="text-sm text-gray-600">{examplePlantCareData.temperature.description}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 2h8"></path>
                  <path d="M9 2v2.4a4 4 0 0 1-1.8 3.3L2 11"></path>
                  <path d="M15 2v2.4a4 4 0 0 0 1.8 3.3L22 11"></path>
                  <path d="M2 11l.8 3.2A6 6 0 0 0 8.2 18l-.2 2"></path>
                  <path d="M22 11l-.8 3.2A6 6 0 0 1 15.8 18l.2 2"></path>
                  <path d="M8 20l4 2 4-2"></path>
                </svg>
              </div>
              <div className="ml-3">
                <h4 className="font-medium text-gray-800">Humidity</h4>
                <p className="text-sm text-gray-600">{examplePlantCareData.humidity.level}. Consider using a humidifier or placing on a pebble tray with water.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 2v17.5A2.5 2.5 0 0 0 11.5 22h.5"></path>
                  <path d="M14 18.5a2.5 2.5 0 0 1 2.5-2.5h.5"></path>
                  <path d="M3 9.5a9.5 9.5 0 0 1 9.5-9.5h9.5"></path>
                </svg>
              </div>
              <div className="ml-3">
                <h4 className="font-medium text-gray-800">Fertilizer</h4>
                <p className="text-sm text-gray-600">{examplePlantCareData.fertilizer.frequency}. {examplePlantCareData.fertilizer.description}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex gap-3">
          <Button className="bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))] flex-1">
            Add to My Plants
          </Button>
          <Button variant="outline" className="border-[hsl(var(--moss-green))] text-[hsl(var(--moss-green))]">
            Download Care Guide
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const CarePlans = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlant, setSelectedPlant] = useState<string | null>(null);
  
  const filteredPlants = popularPlants.filter(plant => 
    plant.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div 
        className="text-center mb-12"
        {...leafUnfurlAnimation}
      >
        <h1 className="text-3xl md:text-4xl font-bold text-[hsl(var(--moss-green-dark))] mb-4">
          Personalized Care Plans
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Get customized care recommendations for your plants based on your specific environment,
          schedule preferences, and growing conditions.
        </p>
      </motion.div>
      
      <Tabs defaultValue="plant-guides" className="w-full">
        <TabsList className="w-full max-w-md mx-auto grid grid-cols-2 mb-8">
          <TabsTrigger value="plant-guides">Plant Guides</TabsTrigger>
          <TabsTrigger value="care-schedule">Care Schedule</TabsTrigger>
        </TabsList>
        
        <TabsContent value="plant-guides" className="mt-0">
          {selectedPlant ? (
            <CareGuide plantName={selectedPlant} onClose={() => setSelectedPlant(null)} />
          ) : (
            <>
              <div className="flex max-w-md mx-auto mb-8">
                <Input 
                  placeholder="Search for a plant..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="rounded-r-none focus-visible:ring-[hsl(var(--moss-green))]"
                />
                <Button className="rounded-l-none bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))]">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg>
                </Button>
              </div>
              
              <motion.div 
                className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
                variants={staggeredContainer}
                initial="initial"
                animate="animate"
              >
                {filteredPlants.map((plant) => (
                  <motion.div 
                    key={plant.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="cursor-pointer group"
                    onClick={() => setSelectedPlant(plant.name)}
                  >
                    <Card className="organic-card overflow-hidden transition-all duration-300 group-hover:-translate-y-2 group-hover:shadow-lg">
                      <div className="relative">
                        <img 
                          src={plant.image} 
                          alt={plant.name} 
                          className="h-48 w-full object-cover"
                        />
                        <div className="absolute bottom-2 right-2">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            difficultyColors[plant.difficulty]
                          )}>
                            {plant.difficulty}
                          </span>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-bold text-[hsl(var(--moss-green-dark))] group-hover:text-[hsl(var(--moss-green))] transition-colors">
                          {plant.name}
                        </h3>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center text-sm text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-[hsl(var(--sky-blue))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M12 2v6"></path>
                              <path d="M5 10l7-6 7 6"></path>
                              <path d="M12 22V12"></path>
                              <path d="M5 18v-6"></path>
                              <path d="M19 18v-6"></path>
                            </svg>
                            <span>Water weekly</span>
                          </div>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))] opacity-0 group-hover:opacity-100 transition-opacity" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M5 12h14"></path>
                            <path d="m12 5 7 7-7 7"></path>
                          </svg>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
                
                {filteredPlants.length === 0 && (
                  <div className="col-span-full text-center py-12">
                    <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="m21 21-4.3-4.3"></path>
                        <path d="M8 11h6"></path>
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium text-gray-900">No plants found</h3>
                    <p className="mt-1 text-gray-500">Try searching for a different plant or browse popular options.</p>
                  </div>
                )}
              </motion.div>
            </>
          )}
        </TabsContent>
        
        <TabsContent value="care-schedule" className="mt-0">
          <Card className="organic-card">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-[hsl(var(--moss-green-dark))]">Weekly Care Schedule</h3>
                <Button className="bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))]">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                  </svg>
                  Add Task
                </Button>
              </div>
              
              <div className="grid gap-4 md:grid-cols-7">
                {weeklySchedule.map((day, index) => (
                  <div key={index} className={cn(
                    "rounded-xl p-4",
                    day.tasks.length > 0 ? "bg-[hsl(var(--moss-green-light))/10]" : "bg-gray-50"
                  )}>
                    <h4 className={cn(
                      "font-medium text-center mb-3",
                      index === new Date().getDay() - 1 ? "text-[hsl(var(--moss-green))]" : "text-gray-700"
                    )}>
                      {day.day}
                    </h4>
                    
                    {day.tasks.length > 0 ? (
                      <ul className="space-y-2">
                        {day.tasks.map((task, taskIndex) => (
                          <li key={taskIndex} className="flex items-start">
                            <div className="h-5 w-5 rounded-full border border-[hsl(var(--moss-green))] flex-shrink-0 mt-0.5"></div>
                            <span className="ml-2 text-sm text-gray-700">{task}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-24">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-300 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10"></circle>
                          <line x1="12" y1="8" x2="12" y2="16"></line>
                          <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                        <span className="text-xs text-gray-400">No tasks</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className="mt-8 p-4 bg-gray-50 rounded-xl">
                <h4 className="font-medium text-[hsl(var(--moss-green-dark))] mb-4">Plant Care Tips</h4>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span className="text-sm text-gray-700">Water your plants in the morning for best absorption.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span className="text-sm text-gray-700">Rotate your plants every week for even growth.</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))] mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span className="text-sm text-gray-700">Check soil moisture before watering to avoid overwatering.</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CarePlans;
