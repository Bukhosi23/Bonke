import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface PlantModelProps {
  growthStage: number;
  maxGrowth: number;
}

// A simple stylized plant model created with code
export function PlantModel({ growthStage, maxGrowth }: PlantModelProps) {
  const group = useRef<THREE.Group>(null);
  
  // Calculate growth progress (0 to 1)
  const growthProgress = Math.max(0.1, Math.min(1, growthStage / maxGrowth));
  
  // Use animated rotation and scale based on growth
  useFrame((state) => {
    if (!group.current) return;
    
    // Gentle swaying motion
    group.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.3) * 0.05;
    
    // Subtle up/down motion
    group.current.position.y = Math.sin(state.clock.getElapsedTime() * 0.2) * 0.02;
  });

  // Determine number of leaves based on growth stage
  const leafCount = Math.max(1, Math.ceil(growthProgress * 5));

  return (
    <group ref={group}>
      {/* Plant stem */}
      <mesh position={[0, growthProgress * 0.8, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.1, growthProgress * 2, 8]} />
        <meshStandardMaterial 
          color={new THREE.Color("#2e7d32")}
          roughness={0.8} 
          metalness={0.1} 
        />
      </mesh>
      
      {/* Plant leaves (more leaves appear as the plant grows) */}
      {Array.from({ length: leafCount }).map((_, index) => {
        const angle = (index / 5) * Math.PI * 2;
        const height = 0.3 + index * 0.15;
        const leafSize = 0.15 + (index / 10);
        
        return (
          <group 
            key={index} 
            position={[0, height * growthProgress, 0]} 
            rotation={[0, angle, 0]}
          >
            <mesh castShadow>
              <boxGeometry args={[leafSize, 0.02, 0.3 * growthProgress]} />
              <meshStandardMaterial 
                color={new THREE.Color("#4caf50")}
                roughness={0.7}
                metalness={0.1}
              />
            </mesh>
          </group>
        );
      })}
      
      {/* Plant flower (only appears when growth reaches 80%) */}
      {growthProgress > 0.8 && (
        <mesh position={[0, growthProgress * 2, 0]} castShadow>
          <sphereGeometry args={[0.15 * (growthProgress - 0.8) * 5, 8, 8]} />
          <meshStandardMaterial 
            color={new THREE.Color("#e91e63")}
            roughness={0.3}
            metalness={0.3}
            emissive={new THREE.Color("#ff8a80")}
            emissiveIntensity={0.3}
          />
        </mesh>
      )}
      
      {/* Plant pot */}
      <mesh position={[0, -0.4, 0]} receiveShadow castShadow>
        <cylinderGeometry args={[0.3, 0.25, 0.5, 16]} />
        <meshStandardMaterial 
          color={new THREE.Color("#795548")}
          roughness={0.9} 
          metalness={0.1} 
        />
      </mesh>
      
      {/* Soil */}
      <mesh position={[0, -0.15, 0]} receiveShadow>
        <cylinderGeometry args={[0.28, 0.28, 0.1, 16]} />
        <meshStandardMaterial 
          color={new THREE.Color("#3e2723")}
          roughness={1} 
          metalness={0} 
        />
      </mesh>
    </group>
  );
}

export default PlantModel;