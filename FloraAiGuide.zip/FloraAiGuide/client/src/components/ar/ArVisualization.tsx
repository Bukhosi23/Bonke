import { useState, useRef, useEffect, Suspense } from 'react';
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PresentationControls, Environment } from '@react-three/drei';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';
import { plantGrowthAnimation } from '@/lib/animations';
import PlantModel from './PlantModel';

// Plant growth stages
const GROWTH_STAGES = [
  { month: 0, height: 0, label: 'Just Planted' },
  { month: 1, height: 0.2, label: '1 Month' },
  { month: 3, height: 0.4, label: '3 Months' },
  { month: 6, height: 0.65, label: '6 Months' },
  { month: 12, height: 0.9, label: '1 Year' },
  { month: 24, height: 1, label: '2 Years' }
];

interface ArVisualizationProps {
  plantImage?: string;
  plantName?: string;
}

const ArVisualization = ({
  plantImage = "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc",
  plantName = "Monstera Deliciosa"
}: ArVisualizationProps) => {
  const [growthStage, setGrowthStage] = useState(3); // Default to 6 months (index 3)
  const [isPlaying, setIsPlaying] = useState(false);
  const [showInfo, setShowInfo] = useState(true);
  const animationRef = useRef<NodeJS.Timeout | null>(null);
  
  // Handle automatic growth animation
  useEffect(() => {
    if (isPlaying) {
      animationRef.current = setInterval(() => {
        setGrowthStage(prev => {
          if (prev >= GROWTH_STAGES.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 2000);
    }
    
    return () => {
      if (animationRef.current) {
        clearInterval(animationRef.current);
      }
    };
  }, [isPlaying]);
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleTimelineChange = (value: number[]) => {
    setGrowthStage(value[0]);
    setIsPlaying(false);
  };
  
  const handleGrowthReset = () => {
    setGrowthStage(0);
    setIsPlaying(false);
  };
  
  const handleGrowthForward = () => {
    if (growthStage < GROWTH_STAGES.length - 1) {
      setGrowthStage(growthStage + 1);
    }
  };
  
  const handleGrowthBack = () => {
    if (growthStage > 0) {
      setGrowthStage(growthStage - 1);
    }
  };

  return (
    <Card className="organic-card w-full overflow-hidden bg-[hsl(var(--moss-green-light))/5] border-0 shadow-lg">
      <CardContent className="p-0 relative">
        <div className="relative w-full aspect-[4/3] bg-gray-100 overflow-hidden">
          {/* Background environment */}
          <img 
            src={plantImage} 
            alt="AR environment" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--moss-green-dark))/80] to-transparent" />
          
          {/* 3D Plant visualization */}
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-full h-full flex items-end justify-center">
            <div 
              className="relative w-full h-full"
              style={{
                transformOrigin: 'bottom center'
              }}
            >
              {/* 3D Canvas */}
              <div className="absolute inset-0 w-full h-full z-10">
                <Suspense fallback={<div className="w-full h-full flex items-center justify-center text-white">Loading 3D model...</div>}>
                  <Canvas
                    shadows
                    camera={{ position: [0, 2, 5], fov: 40 }}
                    style={{ background: 'transparent' }}
                  >
                    {/* Lighting */}
                    <ambientLight intensity={0.4} />
                    <directionalLight 
                      position={[5, 5, 5]} 
                      intensity={0.8} 
                      castShadow 
                    />
                    
                    {/* Plant model */}
                    <PlantModel
                      growthStage={growthStage}
                      maxGrowth={GROWTH_STAGES.length - 1}
                    />
                    
                    {/* Controls */}
                    <OrbitControls 
                      enableZoom={false}
                      enablePan={false}
                      minPolarAngle={Math.PI / 4}
                      maxPolarAngle={Math.PI / 2.2}
                    />
                  </Canvas>
                </Suspense>
              </div>
              
              {/* Fallback 2D visualization for low-end devices or loading state */}
              <motion.div 
                className="absolute bottom-0 w-60 h-60 opacity-0"
                style={{
                  height: `${GROWTH_STAGES[growthStage].height * 75}%`,
                  left: 'calc(50% - 30px)',
                  opacity: 0, // Hidden by default, shown if 3D fails
                }}
                initial="initial"
                animate="animate"
                variants={plantGrowthAnimation}
                key={growthStage}
              >
                <svg viewBox="0 0 100 100" className="absolute bottom-0 w-full h-full fill-[hsl(var(--moss-green))]" preserveAspectRatio="none">
                  <path d="M50,100 C20,80 20,50 30,30 C40,10 45,5 50,0 C55,5 60,10 70,30 C80,50 80,80 50,100 Z" />
                </svg>
              </motion.div>
            </div>
          </div>
          
          {/* AR Controls overlay */}
          <div className="absolute bottom-6 left-0 right-0 px-6">
            <div className="relative mb-8">
              <div className="ar-timeline h-1.5 bg-white/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[hsl(var(--sunbeam-yellow))] rounded-full transition-all duration-300"
                  style={{ width: `${(growthStage / (GROWTH_STAGES.length - 1)) * 100}%` }}
                />
              </div>
              <div 
                className="absolute w-4 h-4 bg-white rounded-full border-2 border-[hsl(var(--sunbeam-yellow))] top-1/2 -mt-2 -ml-2 transition-all duration-300"
                style={{ left: `${(growthStage / (GROWTH_STAGES.length - 1)) * 100}%` }}
              />
              
              <Slider
                value={[growthStage]}
                min={0}
                max={GROWTH_STAGES.length - 1}
                step={1}
                onValueChange={handleTimelineChange}
                className="absolute inset-0 opacity-0"
              />
            </div>
            
            <div className="flex justify-center gap-4">
              <Button 
                onClick={handleGrowthBack}
                variant="ghost" 
                size="icon"
                className="w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm text-[hsl(var(--moss-green-dark))] hover:bg-white"
                disabled={growthStage === 0}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 18a5 5 0 0 1-10 0"></path>
                  <line x1="12" y1="2" x2="12" y2="9"></line>
                  <line x1="4.22" y1="10.22" x2="5.64" y2="11.64"></line>
                  <line x1="1" y1="18" x2="3" y2="18"></line>
                  <line x1="21" y1="18" x2="23" y2="18"></line>
                  <line x1="18.36" y1="11.64" x2="19.78" y2="10.22"></line>
                  <line x1="23" y1="22" x2="1" y2="22"></line>
                </svg>
              </Button>
              
              <Button 
                onClick={handlePlayPause}
                variant="ghost" 
                size="icon"
                className="w-12 h-12 rounded-full bg-white/80 backdrop-blur-sm text-[hsl(var(--moss-green-dark))] hover:bg-white"
              >
                {isPlaying ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="6" y="4" width="4" height="16"></rect>
                    <rect x="14" y="4" width="4" height="16"></rect>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="5 3 19 12 5 21 5 3"></polygon>
                  </svg>
                )}
              </Button>
              
              <Button 
                onClick={handleGrowthForward}
                variant="ghost" 
                size="icon"
                className="w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm text-[hsl(var(--moss-green-dark))] hover:bg-white"
                disabled={growthStage === GROWTH_STAGES.length - 1}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 8a5 5 0 0 0-10 0"></path>
                  <line x1="12" y1="16" x2="12" y2="23"></line>
                  <line x1="4.22" y1="13.78" x2="5.64" y2="12.36"></line>
                  <line x1="1" y1="6" x2="3" y2="6"></line>
                  <line x1="21" y1="6" x2="23" y2="6"></line>
                  <line x1="18.36" y1="12.36" x2="19.78" y2="13.78"></line>
                  <line x1="23" y1="22" x2="1" y2="22"></line>
                </svg>
              </Button>
            </div>
          </div>
          
          {/* Info box in the top right */}
          <div className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-medium">
            {GROWTH_STAGES[growthStage].label}
          </div>
          
          {/* Info card that can be toggled */}
          {showInfo && (
            <motion.div 
              className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm rounded-xl p-3 max-w-[200px] shadow-md"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex justify-between items-start">
                <h4 className="font-medium text-[hsl(var(--moss-green-dark))] text-sm">{plantName}</h4>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 p-0"
                  onClick={() => setShowInfo(false)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </Button>
              </div>
              <p className="text-xs text-gray-700 mt-1">
                {growthStage === 0 && "Just planted! Keep soil moist until established."}
                {growthStage === 1 && "First new leaves are appearing. Ensure bright indirect light."}
                {growthStage === 2 && "Growing steadily. Water when top inch of soil is dry."}
                {growthStage === 3 && "Healthy growth phase. Consider rotating for even growth."}
                {growthStage === 4 && "Maturing nicely. May need fertilizer during growing season."}
                {growthStage === 5 && "Fully mature! Consider repotting if rootbound."}
              </p>
            </motion.div>
          )}
          
          {!showInfo && (
            <Button 
              variant="ghost" 
              size="icon"
              className="absolute top-3 left-3 h-8 w-8 rounded-full bg-white/80 backdrop-blur-sm text-[hsl(var(--moss-green-dark))] hover:bg-white"
              onClick={() => setShowInfo(true)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ArVisualization;
