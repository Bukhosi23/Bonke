import { useState, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { motion } from 'framer-motion';

// Plant growth stages
const GROWTH_STAGES = [
  { month: 0, height: 0, label: 'Just Planted' },
  { month: 1, height: 0.2, label: '1 Month' },
  { month: 3, height: 0.4, label: '3 Months' },
  { month: 6, height: 0.65, label: '6 Months' },
  { month: 12, height: 0.9, label: '1 Year' },
  { month: 24, height: 1, label: '2 Years' }
];

interface SimpleArViewProps {
  plantImage?: string;
  plantName?: string;
}

const SimpleArView = ({
  plantImage = "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc",
  plantName = "Monstera Deliciosa"
}: SimpleArViewProps) => {
  const [growthStage, setGrowthStage] = useState(3); // Default to 6 months (index 3)
  const [isPlaying, setIsPlaying] = useState(false);
  const [showInfo, setShowInfo] = useState(true);
  const animationRef = useRef<NodeJS.Timeout | null>(null);
  
  // Handle automatic growth animation
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    
    if (!isPlaying) {
      animationRef.current = setInterval(() => {
        setGrowthStage(prev => {
          if (prev >= GROWTH_STAGES.length - 1) {
            clearInterval(animationRef.current as NodeJS.Timeout);
            return prev;
          }
          return prev + 1;
        });
      }, 2000);
    } else if (animationRef.current) {
      clearInterval(animationRef.current);
    }
  };
  
  const handleTimelineChange = (value: number[]) => {
    setGrowthStage(value[0]);
    if (animationRef.current) {
      clearInterval(animationRef.current);
      setIsPlaying(false);
    }
  };
  
  const handleGrowthBack = () => {
    if (growthStage > 0) {
      setGrowthStage(growthStage - 1);
    }
  };
  
  const handleGrowthForward = () => {
    if (growthStage < GROWTH_STAGES.length - 1) {
      setGrowthStage(growthStage + 1);
    }
  };

  // Calculate plant height based on growth stage
  const plantHeight = GROWTH_STAGES[growthStage].height * 75;

  return (
    <Card className="w-full overflow-hidden border-0 shadow-lg">
      <CardContent className="p-0 relative">
        <div className="relative w-full aspect-[4/3] bg-gray-100 overflow-hidden">
          {/* Background environment */}
          <img 
            src={plantImage} 
            alt="AR environment" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--moss-green-dark))/80] to-transparent" />
          
          {/* Plant visualization (Simple 2D version) */}
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-full h-full flex items-end justify-center">
            <motion.div 
              className="relative w-[60%]"
              style={{
                height: `${plantHeight}%`
              }}
              initial={{ scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{ duration: 0.5 }}
              key={growthStage}
            >
              {/* Stem */}
              <div 
                className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-[8%] bg-[hsl(var(--moss-green))]"
                style={{ height: '100%' }}
              />
              
              {/* Leaves */}
              {growthStage >= 1 && (
                <>
                  <div 
                    className="absolute bottom-[40%] left-0 w-[40%] h-[15%] bg-[hsl(var(--moss-green-light))] rounded-full rotate-[-20deg]"
                  />
                  <div 
                    className="absolute bottom-[50%] right-0 w-[40%] h-[15%] bg-[hsl(var(--moss-green))] rounded-full rotate-[20deg]"
                  />
                </>
              )}
              
              {growthStage >= 2 && (
                <>
                  <div 
                    className="absolute bottom-[60%] left-[5%] w-[45%] h-[15%] bg-[hsl(var(--moss-green))] rounded-full rotate-[-30deg]"
                  />
                  <div 
                    className="absolute bottom-[70%] right-[5%] w-[45%] h-[15%] bg-[hsl(var(--moss-green-light))] rounded-full rotate-[30deg]"
                  />
                </>
              )}
              
              {growthStage >= 3 && (
                <>
                  <div 
                    className="absolute bottom-[80%] left-[10%] w-[40%] h-[12%] bg-[hsl(var(--moss-green-dark))] rounded-full rotate-[-25deg]"
                  />
                  <div 
                    className="absolute bottom-[85%] right-[10%] w-[40%] h-[12%] bg-[hsl(var(--moss-green))] rounded-full rotate-[25deg]"
                  />
                </>
              )}
              
              {/* Flower */}
              {growthStage >= 4 && (
                <div 
                  className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[25%] h-0 pt-[25%] rounded-full bg-[hsl(var(--sunbeam-yellow))]"
                />
              )}
              
              {/* Pot */}
              <div 
                className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-[30%] h-[15%] bg-[hsl(var(--earth-brown))] rounded-t-sm rounded-b-lg"
                style={{ transform: 'translate(-50%, 90%)' }}
              />
            </motion.div>
          </div>
          
          {/* AR Controls overlay */}
          <div className="absolute bottom-6 left-0 right-0 px-6">
            <div className="relative mb-8">
              <div className="h-1.5 bg-white/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[hsl(var(--sunbeam-yellow))] rounded-full transition-all duration-300"
                  style={{ width: `${(growthStage / (GROWTH_STAGES.length - 1)) * 100}%` }}
                />
              </div>
              <div 
                className="absolute w-4 h-4 bg-white rounded-full border-2 border-[hsl(var(--sunbeam-yellow))] top-1/2 -mt-2 -ml-2 transition-all duration-300"
                style={{ left: `${(growthStage / (GROWTH_STAGES.length - 1)) * 100}%` }}
              />
              
              <Slider
                value={[growthStage]}
                min={0}
                max={GROWTH_STAGES.length - 1}
                step={1}
                onValueChange={handleTimelineChange}
                className="absolute inset-0 opacity-0"
              />
            </div>
            
            <div className="flex justify-center gap-4">
              <Button 
                onClick={handleGrowthBack}
                variant="ghost" 
                size="icon"
                className="w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
                disabled={growthStage === 0}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M15 18l-6-6 6-6"/>
                </svg>
              </Button>
              
              <Button 
                onClick={handlePlayPause}
                variant="ghost" 
                size="icon"
                className="w-12 h-12 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
              >
                {isPlaying ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="6" y="4" width="4" height="16"></rect>
                    <rect x="14" y="4" width="4" height="16"></rect>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="5 3 19 12 5 21 5 3"></polygon>
                  </svg>
                )}
              </Button>
              
              <Button 
                onClick={handleGrowthForward}
                variant="ghost" 
                size="icon"
                className="w-10 h-10 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
                disabled={growthStage === GROWTH_STAGES.length - 1}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 18l6-6-6-6"/>
                </svg>
              </Button>
            </div>
          </div>
          
          {/* Info box in the top right */}
          <div className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-medium">
            {GROWTH_STAGES[growthStage].label}
          </div>
          
          {/* Info card that can be toggled */}
          {showInfo && (
            <motion.div 
              className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm rounded-xl p-3 max-w-[200px] shadow-md"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex justify-between items-start">
                <h4 className="font-medium text-sm">{plantName}</h4>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 p-0"
                  onClick={() => setShowInfo(false)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </Button>
              </div>
              <p className="text-xs text-gray-700 mt-1">
                {growthStage === 0 && "Just planted! Keep soil moist until established."}
                {growthStage === 1 && "First new leaves are appearing. Ensure bright indirect light."}
                {growthStage === 2 && "Growing steadily. Water when top inch of soil is dry."}
                {growthStage === 3 && "Healthy growth phase. Consider rotating for even growth."}
                {growthStage === 4 && "Maturing nicely. May need fertilizer during growing season."}
                {growthStage === 5 && "Fully mature! Consider repotting if rootbound."}
              </p>
            </motion.div>
          )}
          
          {!showInfo && (
            <Button 
              variant="ghost" 
              size="icon"
              className="absolute top-3 left-3 h-8 w-8 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white"
              onClick={() => setShowInfo(true)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SimpleArView;