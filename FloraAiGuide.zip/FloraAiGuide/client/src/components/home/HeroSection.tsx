import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { leafUnfurlAnimation, fadeInAnimation, slideUpAnimation } from '@/lib/animations';

const HeroSection = () => {
  return (
    <section className="relative pt-10 pb-20 overflow-hidden">
      {/* Decorative background blobs */}
      <div className="absolute -right-40 -top-40 w-96 h-96 bg-[hsl(var(--sunbeam-yellow-light))] rounded-full opacity-20 filter blur-3xl"></div>
      <div className="absolute -left-20 top-60 w-72 h-72 bg-[hsl(var(--sky-blue-light))] rounded-full opacity-20 filter blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <motion.div 
            className="mb-12 lg:mb-0 app-section"
            {...leafUnfurlAnimation}
          >
            <h1 className="text-4xl md:text-5xl font-bold text-[hsl(var(--moss-green-dark))] leading-tight">
              Discover the secrets of your plants with <span className="text-[hsl(var(--sunbeam-yellow))]">AI</span>
            </h1>
            <p className="mt-6 text-lg text-gray-600 max-w-lg">
              FloraAI helps you identify plants, create personalized care plans, and connect with a community of plant lovers – all powered by advanced AI.
            </p>
            
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/identify" className="plant-button inline-flex items-center px-8 py-3 bg-[hsl(var(--moss-green))] text-white text-lg font-medium rounded-full shadow-md hover:bg-[hsl(var(--moss-green-light))] transition duration-300 ease-in-out">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="22" y1="12" x2="18" y2="12"></line>
                  <line x1="6" y1="12" x2="2" y2="12"></line>
                  <line x1="12" y1="6" x2="12" y2="2"></line>
                  <line x1="12" y1="22" x2="12" y2="18"></line>
                </svg>
                Identify Now
              </Link>
              <Link href="/care" className="plant-button inline-flex items-center px-8 py-3 border-2 border-[hsl(var(--moss-green))] text-[hsl(var(--moss-green))] text-lg font-medium rounded-full hover:bg-[hsl(var(--moss-green))] hover:text-white transition duration-300 ease-in-out">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                </svg>
                Explore
              </Link>
            </div>
            
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150" alt="User avatar" className="w-10 h-10 rounded-full border-2 border-white" />
                <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150" alt="User avatar" className="w-10 h-10 rounded-full border-2 border-white" />
                <img src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&h=150" alt="User avatar" className="w-10 h-10 rounded-full border-2 border-white" />
              </div>
              <div className="ml-4">
                <div className="flex items-center">
                  <div className="flex text-[hsl(var(--sunbeam-yellow))]">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" strokeWidth="2" stroke="currentColor">
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                  </div>
                  <span className="ml-1 text-gray-600">4.8/5</span>
                </div>
                <p className="text-sm text-gray-500">Trusted by 50k+ plant enthusiasts</p>
              </div>
            </div>
          </motion.div>
          
          <div className="relative">
            <motion.div 
              className="relative z-10 rounded-3xl shadow-2xl overflow-hidden app-section"
              {...fadeInAnimation}
            >
              <img src="https://images.unsplash.com/photo-1558693168-c370615b54e0?auto=format&fit=crop&w=800&h=1000" alt="FloraAI app identifying a Monstera plant" className="w-full object-cover" />
              
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--moss-green-dark))/80] to-transparent flex flex-col justify-end p-6">
                <div className="bg-white/90 rounded-2xl p-4 backdrop-blur-sm shadow-lg">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-[hsl(var(--moss-green))] rounded-full flex items-center justify-center text-white">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3 className="font-semibold text-[hsl(var(--moss-green-dark))]">Monstera Deliciosa</h3>
                      <p className="text-sm text-gray-600">Swiss Cheese Plant</p>
                    </div>
                  </div>
                  
                  <div className="mt-3 grid grid-cols-3 gap-2">
                    <div className="text-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-auto text-[hsl(var(--sky-blue))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                      </svg>
                      <p className="text-xs mt-1">Water weekly</p>
                    </div>
                    <div className="text-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-auto text-[hsl(var(--sunbeam-yellow))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="5"></circle>
                        <line x1="12" y1="1" x2="12" y2="3"></line>
                        <line x1="12" y1="21" x2="12" y2="23"></line>
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                        <line x1="1" y1="12" x2="3" y2="12"></line>
                        <line x1="21" y1="12" x2="23" y2="12"></line>
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                      </svg>
                      <p className="text-xs mt-1">Indirect light</p>
                    </div>
                    <div className="text-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-auto text-[hsl(var(--earth-brown))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path>
                      </svg>
                      <p className="text-xs mt-1">65-85°F</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="absolute -top-6 -right-6 w-24 h-24 bg-[hsl(var(--sunbeam-yellow))] rounded-full flex items-center justify-center app-section"
              animate={{
                scale: [1, 1.05, 1],
                transition: { duration: 3, repeat: Infinity }
              }}
            >
              <span className="font-bold text-white text-sm">New!</span>
            </motion.div>
            
            <motion.div 
              className="absolute -bottom-4 -left-4 p-4 bg-white rounded-2xl shadow-lg app-section"
              {...slideUpAnimation}
            >
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                  <line x1="8" y1="21" x2="16" y2="21"></line>
                  <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
                <p className="ml-2 text-sm font-medium">98% accuracy</p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
