import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface AnimatedPlantProps {
  className?: string;
}

// This component will simulate a 3D plant animation
// using CSS and framer-motion
export default function AnimatedPlant({ className = '' }: AnimatedPlantProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Simulate 3D rotation on mouse move
  useEffect(() => {
    if (!containerRef.current) return;
    
    const container = containerRef.current;
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!container) return;
      
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left; 
      const y = e.clientY - rect.top;
      
      // Calculate rotation based on mouse position
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / 30;
      const rotateY = (centerX - x) / 30;
      
      // Apply the rotation transform
      container.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    };
    
    const handleMouseLeave = () => {
      // Reset rotation when mouse leaves
      container.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
    };
    
    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);
  
  return (
    <div 
      ref={containerRef}
      className={`relative w-80 h-80 transition-transform duration-200 ease-out ${className}`}
    >
      {/* Main plant stem */}
      <motion.div 
        className="absolute left-1/2 bottom-0 w-4 h-48 bg-[hsl(var(--moss-green))] rounded-full"
        initial={{ height: 0 }}
        animate={{ height: 192 }}
        transition={{ duration: 2, delay: 0.5 }}
      />
      
      {/* Plant leaves */}
      {[...Array(5)].map((_, i) => {
        const size = 30 + i * 20; // Leaf size increases
        const angle = (i * 72) + 18; // Distribute leaves in a circle
        const delay = 1.5 + i * 0.3; // Staggered animation
        
        return (
          <motion.div
            key={i}
            className="absolute left-1/2 w-1/2 origin-left"
            style={{ 
              bottom: `${50 + i * 28}px`,
              rotate: `${angle}deg`,
            }}
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            transition={{ duration: 1, delay }}
          >
            <div 
              className="w-full h-full"
              style={{
                borderRadius: "70% 30% 85% 15% / 60% 40% 60% 40%",
                backgroundColor: `hsl(var(--moss-green-${i % 2 ? 'light' : 'dark'}))`
              }}
            />
          </motion.div>
        );
      })}
      
      {/* Plant pot */}
      <motion.div
        className="absolute left-1/2 -translate-x-1/2 bottom-0 w-32 h-24"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="w-full h-6 bg-[hsl(var(--earth-brown-light))] rounded-t-xl" />
        <div className="w-full h-20 bg-[hsl(var(--earth-brown))] rounded-b-lg" 
             style={{ clipPath: 'polygon(0 0, 100% 0, 85% 100%, 15% 100%)' }} 
        />
      </motion.div>
      
      {/* Floating particles */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          className="absolute w-2 h-2 rounded-full bg-[hsl(var(--sunbeam-yellow-light))] opacity-70"
          style={{
            left: `${20 + Math.random() * 60}%`,
            bottom: `${30 + Math.random() * 60}%`,
          }}
          animate={{
            y: [0, -10, 0],
            opacity: [0.3, 0.8, 0.3],
            scale: [1, 1.2, 1]
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2
          }}
        />
      ))}
    </div>
  );
}