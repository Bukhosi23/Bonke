import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { staggeredContainer } from '@/lib/animations';
import OrganicCard from '@/components/ui/animations/OrganicCard';

const features = [
  {
    id: "identify",
    icon: "search",
    title: "Plant Identification",
    description: "Instantly identify any plant with our AI. Simply take a photo and get detailed information about your green friend.",
    image: "https://images.unsplash.com/photo-1520412099551-62b6bafeb5bb?auto=format&fit=crop&w=600&h=400",
    link: "/identify"
  },
  {
    id: "care",
    icon: "seedling",
    title: "Personalized Care Plans",
    description: "Get customized care recommendations based on your specific plant, location, and home environment.",
    image: "https://images.unsplash.com/photo-1463936575829-25148e1db1b8?auto=format&fit=crop&w=600&h=300",
    link: "/care"
  },
  {
    id: "community",
    icon: "users",
    title: "Plant Community",
    description: "Connect with other plant enthusiasts, share tips, and showcase your growing collection.",
    image: "https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?auto=format&fit=crop&w=600&h=300",
    link: "/community"
  },
  {
    id: "ar",
    icon: "eye",
    title: "AR Time Travel",
    description: "See how your plants will grow over time with our augmented reality visualization.",
    image: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=600&h=400",
    link: "/ar-time-travel"
  },
  {
    id: "er",
    icon: "activity",
    title: "Plant ER Mode",
    description: "Emergency diagnostics and treatment for plants showing signs of disease or distress.",
    image: "https://pixabay.com/get/g9315e5ecdd3437b3b8b809a86083ad5c8da7b563cf57b19ed9b9450c69d4426e52097257e210d4334b23645c74b4f2b3fe23d53aa66f8dcdae0c76098e45ff93_1280.jpg",
    link: "/identify"
  },
  {
    id: "carbon",
    icon: "leaf",
    title: "Carbon Tracker",
    description: "Monitor how your plants contribute to reducing your carbon footprint and improving air quality.",
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=600&h=400",
    link: "/carbon-tracker"
  }
];

interface FeatureCardProps {
  feature: typeof features[0];
  index: number;
}

// Icon components
const icons = {
  search: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8"></circle>
      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
  ),
  seedling: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2v8"></path>
      <path d="M4.93 10.93l1.41 1.41"></path>
      <path d="M2 18h2"></path>
      <path d="M20 18h2"></path>
      <path d="M19.07 10.93l-1.41 1.41"></path>
      <path d="M22 22H2"></path>
      <path d="M16 8s-1.5 2-4 2-4-2-4-2"></path>
      <path d="M12 12v3"></path>
      <path d="M12 17v2"></path>
    </svg>
  ),
  users: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
      <circle cx="9" cy="7" r="4"></circle>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
    </svg>
  ),
  eye: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
      <circle cx="12" cy="12" r="3"></circle>
    </svg>
  ),
  activity: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
    </svg>
  ),
  leaf: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path>
      <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path>
    </svg>
  )
};

const FeatureCard = ({ feature, index }: FeatureCardProps) => {
  const Icon = icons[feature.icon as keyof typeof icons];

  return (
    <OrganicCard className="bg-white p-6 shadow-md app-section">
      <div className="w-14 h-14 bg-[hsl(var(--moss-green-light))/20] rounded-2xl flex items-center justify-center mb-6 text-[hsl(var(--moss-green))]">
        <Icon />
      </div>
      
      <h3 className="font-bold text-xl text-[hsl(var(--moss-green-dark))] mb-3">{feature.title}</h3>
      <p className="text-gray-600 mb-6">{feature.description}</p>
      
      {/* Feature visualization */}
      <div className={cn(
        "relative rounded-xl overflow-hidden mb-4",
        feature.id === "ar" && "ar-viewer",
        feature.id === "er" && "bg-red-50 border border-red-100"
      )}>
        <img 
          src={feature.image} 
          alt={feature.title} 
          className="w-full h-48 object-cover" 
        />
        
        {feature.id === "identify" && (
          <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--moss-green-dark))/80] to-transparent flex items-end p-4">
            <div className="bg-white/90 rounded-lg p-2 w-full">
              <div className="flex items-center">
                <div className="animate-pulse w-2 h-8 bg-[hsl(var(--moss-green))] rounded-full mr-2"></div>
                <div>
                  <p className="font-medium text-sm">Identifying...</p>
                  <div className="h-1 w-full bg-gray-200 rounded-full mt-1 overflow-hidden">
                    <div className="h-full bg-[hsl(var(--moss-green))] rounded-full w-3/4"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {feature.id === "ar" && (
          <>
            <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--moss-green-dark))/70] to-transparent"></div>
            
            <div className="ar-timeline">
              <div className="ar-timeline-progress"></div>
            </div>
            <div className="ar-time-marker"></div>
            
            <div className="ar-controls">
              <button className="w-10 h-10 bg-white/80 rounded-full flex items-center justify-center backdrop-blur-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green-dark))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 2v20h20"></path>
                  <path d="M7 12v5h10V8"></path>
                </svg>
              </button>
              <button className="w-10 h-10 bg-white/80 rounded-full flex items-center justify-center backdrop-blur-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green-dark))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <polygon points="10 8 16 12 10 16 10 8"></polygon>
                </svg>
              </button>
              <button className="w-10 h-10 bg-white/80 rounded-full flex items-center justify-center backdrop-blur-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green-dark))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 2v20h20"></path>
                  <path d="M7 12v5h10v5"></path>
                </svg>
              </button>
            </div>
            
            <div className="absolute top-3 right-3 bg-white/80 px-2 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
              6 Months Growth
            </div>
          </>
        )}
        
        {feature.id === "er" && (
          <div className="absolute inset-0 bg-gradient-to-t from-red-500/20 to-transparent flex items-end p-4">
            <div className="bg-white/90 rounded-lg p-2 w-full">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon>
                  <line x1="12" y1="8" x2="12" y2="12"></line>
                  <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
                <div>
                  <p className="font-medium text-sm text-red-600">Critical: Leaf spot detected</p>
                  <div className="h-1 w-full bg-gray-200 rounded-full mt-1 overflow-hidden">
                    <div className="h-full bg-red-500 rounded-full w-2/3"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {feature.id === "carbon" && (
          <div className="absolute top-3 left-3 bg-white/80 px-3 py-1.5 rounded-full text-xs font-medium backdrop-blur-sm flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 22a8 8 0 0 1 8-8v0a8 8 0 0 1 8 8v0"></path>
              <path d="M2 10V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-8"></path>
              <path d="M18 14s-2 3-6 3-6-3-6-3"></path>
            </svg>
            CO₂ Absorbed: 3.2 kg/year
          </div>
        )}
      </div>
      
      <Link href={feature.link} className="plant-button inline-flex items-center text-[hsl(var(--moss-green))] font-medium">
        <span>Learn More</span>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12h14"></path>
          <path d="m12 5 7 7-7 7"></path>
        </svg>
      </Link>
    </OrganicCard>
  );
};

const FeaturesSection = () => {
  return (
    <motion.section 
      className="py-20 bg-gray-50"
      variants={staggeredContainer}
      initial="initial"
      animate="animate"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 app-section">
          <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--moss-green-dark))]">Discover what FloraAI can do</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">Our innovative features help you nurture your green friends and create a thriving plant sanctuary.</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={feature.id} 
              feature={feature} 
              index={index}
            />
          ))}
        </div>
      </div>
    </motion.section>
  );
};

export default FeaturesSection;
