import { motion } from 'framer-motion';
import { staggeredContainer } from '@/lib/animations';
import OrganicCard from '@/components/ui/animations/OrganicCard';

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Plant Parent of 12",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&h=150",
    rating: 5,
    text: "FloraAI has completely transformed my plant care routine. The identification feature is spot-on, and the personalized care plans have saved several of my struggling plants!",
    since: "Using FloraAI since 2022"
  },
  {
    name: "David Chen",
    role: "Urban Gardener",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150",
    rating: 4.5,
    text: "The AR feature is mind-blowing! Being able to visualize how my plants will grow over time has helped me plan my garden layout so much better. The community is also incredibly helpful.",
    since: "Using FloraAI since 2023"
  },
  {
    name: "Emma Rodriguez",
    role: "Houseplant Enthusiast",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&h=150",
    rating: 5,
    text: "I used to kill every plant I touched, but FloraAI's reminders and Plant ER mode have made me a confident plant parent! The carbon tracker is a nice bonus to see my environmental impact.",
    since: "Using FloraAI since 2022"
  }
];

const TestimonialCard = ({ testimonial, index }) => {
  return (
    <OrganicCard className="bg-white p-6 shadow-md app-section">
      <div className="flex items-center mb-4">
        <img src={testimonial.avatar} alt={`${testimonial.name} avatar`} className="w-12 h-12 rounded-full" />
        <div className="ml-3">
          <h4 className="font-bold text-[hsl(var(--moss-green-dark))]">{testimonial.name}</h4>
          <p className="text-sm text-gray-500">{testimonial.role}</p>
        </div>
      </div>
      <div className="flex text-[hsl(var(--sunbeam-yellow))] mb-4">
        {Array.from({ length: Math.floor(testimonial.rating) }).map((_, i) => (
          <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
          </svg>
        ))}
        {testimonial.rating % 1 !== 0 && (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2l2.2 6.27L22 9.24l-5 4.67 1.18 6.63L12 17.77 6.82 20.54 8 13.91l-5-4.67 7.8-.97L12 2z" fill="url(#half-star)"></path>
            <defs>
              <linearGradient id="half-star">
                <stop offset="50%" stopColor="currentColor"></stop>
                <stop offset="50%" stopColor="transparent" stopOpacity="1"></stop>
              </linearGradient>
            </defs>
          </svg>
        )}
      </div>
      <p className="text-gray-600 mb-4">{testimonial.text}</p>
      <p className="text-sm text-gray-500">{testimonial.since}</p>
    </OrganicCard>
  );
};

const TestimonialsSection = () => {
  return (
    <motion.section 
      className="py-20 bg-gray-50"
      variants={staggeredContainer}
      initial="initial"
      animate="animate"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 app-section">
          <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--moss-green-dark))]">What plant lovers are saying</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">Join thousands of happy plant parents who've transformed their green spaces with FloraAI.</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} index={index} />
          ))}
        </div>
      </div>
    </motion.section>
  );
};

export default TestimonialsSection;
