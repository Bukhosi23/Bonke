import { useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { plantGrowthAnimation, floatingAnimation } from '@/lib/animations';
import { exampleIdentificationResults, examplePlantCareData } from '@/lib/plantData';

const examplePlants = [
  {
    id: 1,
    name: "Monstera",
    image: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=200&h=200"
  },
  {
    id: 2,
    name: "Succulent",
    image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=200&h=200"
  },
  {
    id: 3,
    name: "Fiddle Leaf Fig",
    image: "https://images.unsplash.com/photo-1597055181900-23778533afd9?auto=format&fit=crop&w=200&h=200"
  }
];

const InteractiveDemo = () => {
  const [selectedPlant, setSelectedPlant] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isIdentified, setIsIdentified] = useState(false);

  const handleFileUpload = () => {
    // In a real app, this would handle file upload
    // For demo purposes, we'll just set a random example plant
    const randomPlant = Math.floor(Math.random() * examplePlants.length);
    setSelectedPlant(examplePlants[randomPlant].id);
    setTimeout(() => {
      setIsIdentified(true);
    }, 2000);
  };

  const handlePlantSelect = (plantId: number) => {
    setSelectedPlant(plantId);
    setTimeout(() => {
      setIsIdentified(true);
    }, 2000);
  };

  return (
    <section className="py-20 bg-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-2/3 h-full bg-[hsl(var(--moss-green-light))/10] organic-blob"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
          <motion.div 
            className="mb-12 lg:mb-0 app-section"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-[hsl(var(--moss-green-dark))] mb-6">Try FloraAI right in your browser</h2>
            <p className="text-lg text-gray-600 mb-8">Experience the power of our plant identification technology with this interactive demo. Upload an image or try one of our examples.</p>
            
            {/* Interactive demo UI */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div 
                className={cn(
                  "flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-8 mb-6 transition-all duration-300",
                  isDragging ? "border-[hsl(var(--moss-green))] bg-[hsl(var(--moss-green-light))/10]" : "border-gray-300 bg-gray-50",
                  selectedPlant && !isIdentified ? "animate-pulse" : ""
                )}
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  handleFileUpload();
                }}
              >
                {selectedPlant && !isIdentified ? (
                  <>
                    <div className="w-16 h-16 rounded-full border-4 border-t-[hsl(var(--moss-green))] border-r-[hsl(var(--moss-green))] border-b-transparent border-l-transparent animate-spin mb-4"></div>
                    <p className="text-gray-600 mb-2">Identifying your plant...</p>
                    <p className="text-gray-500 text-sm">This will only take a moment</p>
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-[hsl(var(--moss-green-light))] mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                      <polyline points="17 8 12 3 7 8"></polyline>
                      <line x1="12" y1="3" x2="12" y2="15"></line>
                    </svg>
                    <p className="text-gray-600 mb-2">Drop your plant photo here</p>
                    <p className="text-gray-500 text-sm mb-4">or</p>
                    <button 
                      className="plant-button bg-[hsl(var(--moss-green))] text-white py-2 px-6 rounded-full hover:bg-[hsl(var(--moss-green-light))] transition duration-300"
                      onClick={handleFileUpload}
                    >
                      Choose Photo
                    </button>
                  </>
                )}
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-3">Or try one of these examples:</p>
                <div className="grid grid-cols-3 gap-3">
                  {examplePlants.map((plant) => (
                    <button
                      key={plant.id}
                      className={cn(
                        "rounded-lg overflow-hidden border-2 transition-all duration-300",
                        selectedPlant === plant.id ? "border-[hsl(var(--moss-green))]" : "border-transparent hover:border-[hsl(var(--moss-green))]"
                      )}
                      onClick={() => handlePlantSelect(plant.id)}
                    >
                      <img src={plant.image} alt={`${plant.name} example`} className="w-full h-20 object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <div className="flex items-center mb-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))] mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
                <p className="text-sm text-gray-600">Your photos are processed securely and never stored without permission.</p>
              </div>
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))] mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
                </svg>
                <p className="text-sm text-gray-600">Identification happens in seconds, even offline.</p>
              </div>
            </div>
          </motion.div>
          
          <div className="relative app-section">
            {/* The result of plant identification */}
            <motion.div 
              className="bg-white rounded-3xl shadow-xl overflow-hidden p-6 max-w-md mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isIdentified ? 1 : 0, y: isIdentified ? 0 : 30 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-xl text-[hsl(var(--moss-green-dark))]">Plant Identified!</h3>
                <button className="text-[hsl(var(--moss-green-dark))]">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
                    <polyline points="16 6 12 2 8 6"></polyline>
                    <line x1="12" y1="2" x2="12" y2="15"></line>
                  </svg>
                </button>
              </div>
              
              <div className="rounded-2xl overflow-hidden mb-6">
                <img src="https://pixabay.com/get/ga1be4dda9b7067763d4644bae9ce0edfb3e0e4b312d1bf91a656eb244a04aec16c00843a99c294bb90700ab9ec90abdbc2a6c728b0cd1958756548efab65ce64_1280.jpg" alt="Identified fiddle leaf fig" className="w-full h-64 object-cover" />
              </div>
              
              <div className="mb-6">
                <h4 className="font-bold text-2xl text-[hsl(var(--moss-green-dark))]">{exampleIdentificationResults.commonName}</h4>
                <p className="text-gray-600">{exampleIdentificationResults.scientificName}</p>
                
                <div className="flex items-center mt-2">
                  <div className="flex items-center bg-[hsl(var(--moss-green-light))/20] px-3 py-1 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[hsl(var(--moss-green-dark))] mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    <span className="text-xs font-medium text-[hsl(var(--moss-green-dark))]">{exampleIdentificationResults.confidence}% Match</span>
                  </div>
                  <div className="ml-2 bg-gray-100 px-3 py-1 rounded-full">
                    <span className="text-xs font-medium text-gray-600">Indoor Plant</span>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-100 pt-4 pb-2">
                <h5 className="font-medium text-[hsl(var(--moss-green-dark))] mb-3">Quick Care Tips:</h5>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sky-blue))] mt-1 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                      <path d="M2 17l10 5 10-5"></path>
                      <path d="M2 12l10 5 10-5"></path>
                    </svg>
                    <div>
                      <p className="font-medium text-gray-800">Water</p>
                      <p className="text-sm text-gray-600">{examplePlantCareData.water.description}</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))] mt-1 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="5"></circle>
                      <line x1="12" y1="1" x2="12" y2="3"></line>
                      <line x1="12" y1="21" x2="12" y2="23"></line>
                      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                      <line x1="1" y1="12" x2="3" y2="12"></line>
                      <line x1="21" y1="12" x2="23" y2="12"></line>
                      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                    </svg>
                    <div>
                      <p className="font-medium text-gray-800">Light</p>
                      <p className="text-sm text-gray-600">{examplePlantCareData.light.description}</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--earth-brown))] mt-1 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path>
                    </svg>
                    <div>
                      <p className="font-medium text-gray-800">Temperature</p>
                      <p className="text-sm text-gray-600">{examplePlantCareData.temperature.description}</p>
                    </div>
                  </li>
                </ul>
              </div>
              
              <div className="mt-4 grid grid-cols-2 gap-3">
                <button className="plant-button bg-[hsl(var(--moss-green))] text-white py-3 rounded-xl hover:bg-[hsl(var(--moss-green-light))] transition duration-300 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                  </svg>
                  <span>Create Care Plan</span>
                </button>
                <button className="plant-button border border-[hsl(var(--moss-green))] text-[hsl(var(--moss-green))] py-3 rounded-xl hover:bg-[hsl(var(--moss-green))] hover:text-white transition duration-300 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                  </svg>
                  <span>Learn More</span>
                </button>
              </div>
            </motion.div>
            
            {/* Floating notification */}
            <motion.div 
              className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-lg p-4 max-w-xs app-section"
              initial={{ opacity: 0, y: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              variants={floatingAnimation}
              whileInView="animate"
              viewport={{ once: false }}
            >
              <div className="flex">
                <div className="w-12 h-12 bg-[hsl(var(--sky-blue))/20] rounded-full flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[hsl(var(--sky-blue))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="font-medium text-[hsl(var(--moss-green-dark))]">Time to water your Monstera!</p>
                  <p className="text-sm text-gray-500 mt-1">Last watered 7 days ago</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveDemo;
