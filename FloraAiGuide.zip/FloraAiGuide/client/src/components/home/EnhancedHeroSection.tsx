import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import AnimatedPlant from './AnimatedPlant';
import { useIsMobile } from '@/hooks/use-mobile';

export default function EnhancedHeroSection() {
  const isMobile = useIsMobile();
  const [scrolled, setScrolled] = useState(false);
  
  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Floating Leaves Background */}
      <div className="fixed inset-0 -z-10 opacity-30 pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-12 h-12 opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `-5%`,
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2348BB78'%3E%3Cpath d='M12 22q-4.025 0-7.013-2.425T2 13.175q0-3.9 3.688-8.4Q9.375 1 12 1q2.625 0 6.313 3.775Q22 8.55 22 13.15q0 3.875-2.988 6.3T12 22Z'/%3E%3C/svg%3E")`,
              backgroundSize: 'contain',
              backgroundRepeat: 'no-repeat',
              transform: `rotate(${Math.random() * 360}deg)`
            }}
            initial={{ y: -100, rotate: 0 }}
            animate={{
              y: window.innerHeight,
              rotate: 360,
              x: Math.sin(Date.now() * 0.001 + i) * 100
            }}
            transition={{
              duration: 8 + Math.random() * 5,
              repeat: Infinity,
              ease: 'linear'
            }}
          />
        ))}
      </div>
      
      <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center">
        <motion.div 
          className="w-full lg:w-1/2 lg:pr-12 mb-10 lg:mb-0 z-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
            <span className="block text-[hsl(var(--moss-green-dark))]">Meet Your Plant's</span>
            <span className="block mt-2 text-[hsl(var(--sunbeam-yellow))]">Digital Soulmate</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-gray-700 mb-8 max-w-xl">
            Experience the future of plant care with FloraAI. Identify plants, get personalized care plans,
            and track your environmental impact with our AI-powered companion.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <Link href="/identify">
              <motion.button
                className="plant-button px-8 py-3 bg-[hsl(var(--moss-green))] text-white font-medium rounded-full shadow-lg hover:shadow-[hsl(var(--moss-green-light))]/30"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                Start Plant Identification
              </motion.button>
            </Link>
            
            <Link href="/auth">
              <motion.button
                className="plant-button px-8 py-3 border-2 border-[hsl(var(--moss-green))] text-[hsl(var(--moss-green-dark))] font-medium rounded-full"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                Create Account
              </motion.button>
            </Link>
          </div>
          
          <div className="mt-10 flex items-center space-x-4">
            <p className="text-sm text-gray-600">Trusted by plant lovers:</p>
            <div className="flex space-x-2">
              <div className="w-8 h-8 bg-[hsl(var(--moss-green))] rounded-full flex items-center justify-center text-white text-xs">
                5K+
              </div>
              <div className="w-8 h-8 bg-[hsl(var(--sunbeam-yellow))] rounded-full flex items-center justify-center text-white text-xs">
                4.9★
              </div>
              <div className="w-8 h-8 bg-[hsl(var(--sky-blue))] rounded-full flex items-center justify-center text-white text-xs">
                AI
              </div>
            </div>
          </div>
        </motion.div>
        
        <motion.div
          className="w-full lg:w-1/2 flex justify-center lg:justify-end"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <div className="relative w-full max-w-md">
            <div className="absolute inset-0 bg-gradient-to-b from-[hsl(var(--sunbeam-yellow-light))]/10 to-transparent rounded-full filter blur-3xl opacity-60" />
            
            <AnimatedPlant className="mx-auto" />
            
            {/* Indicator dots */}
            <motion.div 
              className="absolute top-1/3 -left-4 w-4 h-4 bg-[hsl(var(--sunbeam-yellow))] rounded-full"
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.7, 1, 0.7] 
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            
            <motion.div 
              className="absolute bottom-1/3 -right-4 w-4 h-4 bg-[hsl(var(--sky-blue))] rounded-full"
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.7, 1, 0.7] 
              }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.7 }}
            />
            
            {/* Floating features */}
            <motion.div
              className="absolute -top-5 -right-5 px-4 py-2 bg-white rounded-lg shadow-lg text-sm font-medium flex items-center"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <span className="w-3 h-3 bg-[hsl(var(--moss-green))] rounded-full mr-2" />
              AI Identification
            </motion.div>
            
            <motion.div
              className="absolute -bottom-5 -left-5 px-4 py-2 bg-white rounded-lg shadow-lg text-sm font-medium flex items-center"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.3 }}
            >
              <span className="w-3 h-3 bg-[hsl(var(--sunbeam-yellow))] rounded-full mr-2" />
              Smart Care Plans
            </motion.div>
          </div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center text-[hsl(var(--moss-green-dark))]"
        animate={{ 
          y: [0, 10, 0],
          opacity: scrolled ? 0 : 1
        }}
        transition={{ 
          y: { duration: 1.5, repeat: Infinity },
          opacity: { duration: 0.3 }
        }}
      >
        <p className="text-sm mb-2 font-medium">Scroll to explore</p>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 20L12 4M12 20L6 14M12 20L18 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </motion.div>
    </section>
  );
}