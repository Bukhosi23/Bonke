import { motion } from 'framer-motion';
import { fadeInAnimation, slideUpAnimation, floatingAnimation } from '@/lib/animations';

const DownloadSection = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-[hsl(var(--moss-green-dark))] to-[hsl(var(--moss-green))] relative overflow-hidden">
      {/* Background decoration blobs */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <div className="absolute -right-40 -top-40 w-96 h-96 bg-white rounded-full"></div>
        <div className="absolute -left-20 top-60 w-72 h-72 bg-[hsl(var(--sunbeam-yellow))] rounded-full"></div>
        <div className="absolute bottom-0 right-20 w-80 h-80 bg-[hsl(var(--sky-blue))] rounded-full"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <motion.div 
            className="text-center lg:text-left mb-12 lg:mb-0 app-section"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to grow with FloraAI?</h2>
            <p className="text-xl text-white/80 mb-8">Download our app today and start your journey to becoming a plant expert.</p>
            
            <div className="flex flex-wrap justify-center lg:justify-start gap-4">
              <a href="#" className="bg-black text-white rounded-xl px-6 py-3 flex items-center hover:bg-gray-900 transition duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                </svg>
                <div className="text-left">
                  <p className="text-xs">Download on the</p>
                  <p className="text-lg font-medium">App Store</p>
                </div>
              </a>
              <a href="#" className="bg-black text-white rounded-xl px-6 py-3 flex items-center hover:bg-gray-900 transition duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-3" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                </svg>
                <div className="text-left">
                  <p className="text-xs">Get it on</p>
                  <p className="text-lg font-medium">Google Play</p>
                </div>
              </a>
            </div>
            
            <div className="mt-8 text-white/70 flex flex-col sm:flex-row items-center justify-center lg:justify-start">
              <div className="flex items-center mb-4 sm:mb-0 sm:mr-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                <span>50K+ Downloads</span>
              </div>
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                <span>4.8/5 Rating</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="relative app-section"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="max-w-xs mx-auto lg:max-w-sm">
              <img 
                src="https://images.unsplash.com/photo-1591160690555-5debfba289f0?auto=format&fit=crop&w=800&h=1200" 
                alt="FloraAI app on smartphone" 
                className="w-full rounded-3xl shadow-2xl"
              />
              
              <motion.div 
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg w-56"
                variants={floatingAnimation}
                initial="initial"
                animate="animate"
              >
                <h4 className="font-bold text-[hsl(var(--moss-green-dark))] text-center mb-2">Start Your Plant Journey</h4>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center text-[hsl(var(--moss-green))]">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p className="ml-2 text-sm">Identify any plant</p>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center text-[hsl(var(--moss-green))]">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p className="ml-2 text-sm">Get care reminders</p>
                  </div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-[hsl(var(--moss-green-light))/20] rounded-full flex items-center justify-center text-[hsl(var(--moss-green))]">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </div>
                    <p className="ml-2 text-sm">Join the community</p>
                  </div>
                </div>
                <button className="w-full bg-[hsl(var(--moss-green))] text-white font-medium py-2 rounded-lg mt-3 hover:bg-[hsl(var(--moss-green-light))] transition duration-300">
                  Get Started
                </button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default DownloadSection;
