import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { cn, calculateCarbonImpact, formatNumber } from '@/lib/utils';
import { exampleCarbonData } from '@/lib/plantData';
import { leafUnfurlAnimation } from '@/lib/animations';

interface CarbonTrackerProps {
  userId?: number;
  initialData?: typeof exampleCarbonData;
}

const CarbonTracker = ({ userId, initialData = exampleCarbonData }: CarbonTrackerProps) => {
  const [carbonData, setCarbonData] = useState(initialData);
  const [activeTab, setActiveTab] = useState('impact');
  
  // Fetch carbon data from API
  useEffect(() => {
    if (userId) {
      // In a real app, this would fetch from the API
      // For demo, we're using the example data
      const fetchCarbonData = async () => {
        try {
          const response = await fetch(`/api/carbon-tracking/${userId}`);
          if (response.ok) {
            const data = await response.json();
            setCarbonData({
              totalPlants: data.totalPlants,
              co2Absorbed: data.co2Absorbed,
              oxygenProduced: data.oxygenProduced,
              airPurified: data.airPurified,
              impactPercentage: Math.min(Math.round(data.totalPlants * 8), 100)
            });
          }
        } catch (error) {
          console.error('Failed to fetch carbon data:', error);
        }
      };
      
      fetchCarbonData();
    }
  }, [userId]);
  
  // Simulate adding a plant
  const handleAddPlant = () => {
    const newData = calculateCarbonImpact(carbonData.totalPlants + 1);
    setCarbonData(newData);
  };
  
  return (
    <div className="max-w-4xl mx-auto px-4">
      <motion.div 
        className="mb-8"
        {...leafUnfurlAnimation}
      >
        <h2 className="text-2xl font-bold text-[hsl(var(--moss-green-dark))] mb-2">Your Carbon Impact</h2>
        <p className="text-gray-600">
          Track how your plants contribute to reducing your carbon footprint and improving air quality.
        </p>
      </motion.div>
      
      <Tabs 
        defaultValue="impact" 
        className="w-full"
        onValueChange={setActiveTab}
      >
        <TabsList className="grid w-full max-w-md grid-cols-3 mb-8">
          <TabsTrigger value="impact">Impact</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>
        
        <TabsContent value="impact" className="mt-0">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="organic-card md:col-span-2">
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="flex flex-col items-center justify-center p-4 bg-[hsl(var(--moss-green-light))/10] rounded-xl">
                    <div className="w-16 h-16 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center mb-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2v20M2 5h20M2 19h20M5 12h14"></path>
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-[hsl(var(--moss-green-dark))]">Plants</h3>
                    <p className="text-3xl font-bold mt-1">{carbonData.totalPlants}</p>
                    <Button 
                      onClick={handleAddPlant}
                      className="mt-3 bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))] text-white text-sm h-8"
                    >
                      Add Plant
                    </Button>
                  </div>
                  
                  <div className="flex flex-col">
                    <div className="relative h-40 w-40 mx-auto">
                      <div 
                        className="carbon-tracker-circle w-full h-full"
                        style={{
                          background: `conic-gradient(hsl(var(--moss-green)) 0% ${carbonData.impactPercentage}%, #E9ECEF ${carbonData.impactPercentage}% 100%)`
                        }}
                      />
                      <div className="carbon-tracker-text absolute inset-0 flex items-center justify-center">
                        <p className="font-bold text-3xl text-[hsl(var(--moss-green-dark))]">{carbonData.impactPercentage}%</p>
                      </div>
                    </div>
                    <p className="text-center text-sm text-gray-600 mt-2">
                      Your positive environmental impact based on your {carbonData.totalPlants} plants.
                    </p>
                  </div>
                  
                  <div className="flex flex-col justify-center">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm text-gray-600">CO₂ absorbed yearly</span>
                          <span className="font-medium">{formatNumber(carbonData.co2Absorbed)} g</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[hsl(var(--moss-green))] rounded-full"
                            style={{ width: `${Math.min(carbonData.co2Absorbed / 50, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm text-gray-600">Oxygen produced</span>
                          <span className="font-medium">{formatNumber(carbonData.oxygenProduced)} g</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[hsl(var(--sunbeam-yellow))] rounded-full"
                            style={{ width: `${Math.min(carbonData.oxygenProduced / 30, 100)}%` }}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm text-gray-600">Air purified daily</span>
                          <span className="font-medium">{carbonData.airPurified} m³</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[hsl(var(--sky-blue))] rounded-full"
                            style={{ width: `${Math.min(carbonData.airPurified / 15 * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="organic-card">
              <CardHeader>
                <CardTitle className="text-[hsl(var(--moss-green-dark))]">Equivalent Impact</CardTitle>
                <CardDescription>What your plants' CO₂ absorption equals to</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Digital Emissions</h4>
                      <p className="text-sm text-gray-600">
                        Offsets {Math.round(carbonData.co2Absorbed / 320 * 100)}% of your yearly smartphone usage
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M19 17h2a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2"></path>
                        <path d="M13 15V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h9"></path>
                        <path d="M13 15h6"></path>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Driving Distance</h4>
                      <p className="text-sm text-gray-600">
                        Equivalent to reducing {Math.round(carbonData.co2Absorbed / 100)} miles of driving
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--moss-green-light))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 13h6v8H2zM14 13h6v8h-6zM8 6h6v15H8z"></path>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Energy Usage</h4>
                      <p className="text-sm text-gray-600">
                        Offsets about {Math.round(carbonData.co2Absorbed / 150)} kWh of electricity
                      </p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="organic-card">
              <CardHeader>
                <CardTitle className="text-[hsl(var(--moss-green-dark))]">Health Benefits</CardTitle>
                <CardDescription>How your plants improve your wellbeing</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--sunbeam-yellow))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                        <line x1="9" y1="9" x2="9.01" y2="9"></line>
                        <line x1="15" y1="9" x2="15.01" y2="9"></line>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Stress Reduction</h4>
                      <p className="text-sm text-gray-600">
                        Plants can reduce stress levels by up to 30-40%
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--sunbeam-yellow))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Productivity</h4>
                      <p className="text-sm text-gray-600">
                        Indoor plants can increase productivity by up to 15%
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-[hsl(var(--sunbeam-yellow))/20] flex items-center justify-center flex-shrink-0 mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[hsl(var(--sunbeam-yellow))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-[hsl(var(--moss-green-dark))]">Air Quality</h4>
                      <p className="text-sm text-gray-600">
                        Your plants remove toxins like formaldehyde and benzene
                      </p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="statistics" className="mt-0">
          <Card className="organic-card">
            <CardHeader>
              <CardTitle className="text-[hsl(var(--moss-green-dark))]">Carbon Statistics</CardTitle>
              <CardDescription>Detailed statistics about your plants' impact</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-[hsl(var(--moss-green-dark))] mb-4">CO₂ Absorption by Plant Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-[hsl(var(--moss-green-light))/10] rounded-xl p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">Monstera Deliciosa</span>
                        <span className="font-semibold">{carbonData.totalPlants >= 1 ? "320g/year" : "0g/year"}</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[hsl(var(--moss-green))] rounded-full"
                          style={{ width: carbonData.totalPlants >= 1 ? "85%" : "0%" }}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-[hsl(var(--moss-green-light))/10] rounded-xl p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">Snake Plant</span>
                        <span className="font-semibold">{carbonData.totalPlants >= 2 ? "250g/year" : "0g/year"}</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[hsl(var(--moss-green))] rounded-full"
                          style={{ width: carbonData.totalPlants >= 2 ? "65%" : "0%" }}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-[hsl(var(--moss-green-light))/10] rounded-xl p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">Peace Lily</span>
                        <span className="font-semibold">{carbonData.totalPlants >= 3 ? "280g/year" : "0g/year"}</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[hsl(var(--moss-green))] rounded-full"
                          style={{ width: carbonData.totalPlants >= 3 ? "70%" : "0%" }}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-[hsl(var(--moss-green-light))/10] rounded-xl p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">Fiddle Leaf Fig</span>
                        <span className="font-semibold">{carbonData.totalPlants >= 4 ? "380g/year" : "0g/year"}</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[hsl(var(--moss-green))] rounded-full"
                          style={{ width: carbonData.totalPlants >= 4 ? "95%" : "0%" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-100">
                  <h3 className="text-lg font-medium text-[hsl(var(--moss-green-dark))] mb-4">Monthly Impact Tracking</h3>
                  <div className="h-60 bg-[hsl(var(--moss-green-light))/5] rounded-xl p-4 flex items-end justify-around">
                    {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, index) => {
                      // Generate a pseudo-random height based on month and total plants
                      const randomHeight = 20 + ((index * 7) % 35) + (carbonData.totalPlants * 5);
                      const height = `${Math.min(randomHeight, 80)}%`;
                      const currentMonth = new Date().getMonth();
                      
                      return (
                        <div key={month} className="flex flex-col items-center">
                          <div className="w-6 bg-[hsl(var(--moss-green))] rounded-t-sm" style={{ height, opacity: index > currentMonth ? 0.3 : 1 }} />
                          <span className="text-xs mt-2 text-gray-500">{month}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="goals" className="mt-0">
          <Card className="organic-card">
            <CardHeader>
              <CardTitle className="text-[hsl(var(--moss-green-dark))]">Environmental Goals</CardTitle>
              <CardDescription>Set targets and track your progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-[hsl(var(--moss-green-light))/10] rounded-xl p-5">
                  <h3 className="text-lg font-medium text-[hsl(var(--moss-green-dark))] mb-4">Carbon Neutrality Progress</h3>
                  
                  <div className="relative pt-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="text-xs font-semibold inline-block text-[hsl(var(--moss-green-dark))]">
                          {carbonData.impactPercentage}% Complete
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold inline-block text-[hsl(var(--moss-green-dark))]">
                          Goal: 100%
                        </span>
                      </div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div 
                        className="h-full rounded-full bg-gradient-to-r from-[hsl(var(--moss-green-light))] to-[hsl(var(--moss-green))]"
                        style={{ width: `${carbonData.impactPercentage}%` }}
                      />
                    </div>
                    
                    <div className="mt-4 text-sm text-gray-600">
                      <p>To reach your carbon neutrality goal, consider:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>Adding {10 - Math.min(carbonData.totalPlants, 10)} more plants</li>
                        <li>Focusing on plants with high CO₂ absorption</li>
                        <li>Ensuring optimal growing conditions</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[hsl(var(--sky-blue))/10] rounded-xl p-5">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-[hsl(var(--moss-green-dark))]">Biodiversity Goal</h3>
                        <p className="text-sm text-gray-600 mt-1">Grow 10 different plant species</p>
                      </div>
                      <div className="bg-[hsl(var(--sky-blue))/20] h-10 w-10 rounded-full flex items-center justify-center text-[hsl(var(--sky-blue))]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                        </svg>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Progress: {Math.min(carbonData.totalPlants, 5)}/10 species</span>
                        <span>{Math.min(carbonData.totalPlants * 10, 50)}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-full rounded-full bg-[hsl(var(--sky-blue))]"
                          style={{ width: `${Math.min(carbonData.totalPlants * 10, 50)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-[hsl(var(--sunbeam-yellow))/10] rounded-xl p-5">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-[hsl(var(--moss-green-dark))]">Air Quality Goal</h3>
                        <p className="text-sm text-gray-600 mt-1">Purify 25m³ of air daily</p>
                      </div>
                      <div className="bg-[hsl(var(--sunbeam-yellow))/20] h-10 w-10 rounded-full flex items-center justify-center text-[hsl(var(--sunbeam-yellow))]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M12 2v6M12 18v4M4.93 10.93l1.41 1.41M17.66 10.93l-1.41 1.41M2 16h2M20 16h2M6 20h12M12 12l2.25 2.25M12 12l3.75-3.75M12 12L9 9M12 12l-3 3"></path>
                        </svg>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex justify-between text-xs mb-1">
                        <span>Current: {carbonData.airPurified}m³/day</span>
                        <span>{Math.min(Math.round(carbonData.airPurified / 25 * 100), 100)}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-full rounded-full bg-[hsl(var(--sunbeam-yellow))]"
                          style={{ width: `${Math.min(Math.round(carbonData.airPurified / 25 * 100), 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-6 border-t border-gray-100">
                  <h3 className="text-lg font-medium text-[hsl(var(--moss-green-dark))] mb-4">Suggested Actions</h3>
                  
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full border-2 border-[hsl(var(--moss-green))] flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-[hsl(var(--moss-green))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="ml-2 text-gray-700">Add 3 more air-purifying plants to your collection</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full border-2 border-gray-300 flex-shrink-0 mt-0.5"></div>
                      <span className="ml-2 text-gray-700">Try adding a Rubber Plant (Ficus elastica) for high CO₂ absorption</span>
                    </li>
                    <li className="flex items-start">
                      <div className="h-6 w-6 rounded-full border-2 border-gray-300 flex-shrink-0 mt-0.5"></div>
                      <span className="ml-2 text-gray-700">Maintain optimal growing conditions for maximum impact</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6">
              <Button className="w-full bg-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green-light))]">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                Set New Goal
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CarbonTracker;
