import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';

interface LeafUnfurlProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

const LeafUnfurl = ({ 
  children, 
  delay = 0,
  className,
  ...props 
}: LeafUnfurlProps) => {
  return (
    <motion.div
      initial={{ scale: 0.8, rotate: -5, opacity: 0 }}
      animate={{ scale: 1, rotate: 0, opacity: 1 }}
      transition={{ 
        duration: 0.8, 
        ease: "easeOut",
        delay
      }}
      className={cn("origin-center", className)}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default LeafUnfurl;
