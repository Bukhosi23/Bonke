import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PlantButtonProps extends HTMLMotionProps<"button"> {
  children: React.ReactNode;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline';
  isLink?: boolean;
}

const PlantButton = ({ 
  children, 
  className,
  variant = 'primary',
  isLink = false,
  ...props 
}: PlantButtonProps) => {
  const buttonStyles = {
    primary: "bg-[hsl(var(--moss-green))] text-white hover:bg-[hsl(var(--moss-green-light))]",
    secondary: "bg-[hsl(var(--sunbeam-yellow))] text-[hsl(var(--moss-green-dark))] hover:bg-[hsl(var(--sunbeam-yellow-light))]",
    outline: "border-2 border-[hsl(var(--moss-green))] text-[hsl(var(--moss-green))] hover:bg-[hsl(var(--moss-green))] hover:text-white"
  };

  const ButtonComponent = isLink ? motion.a : motion.button;
  
  return (
    <ButtonComponent
      className={cn(
        "plant-button inline-flex items-center justify-center px-6 py-3 font-medium rounded-full shadow-md transition-all duration-300 overflow-hidden relative",
        buttonStyles[variant],
        className
      )}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      {...props}
    >
      {children}
    </ButtonComponent>
  );
};

export default PlantButton;
