import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';

interface OrganicCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  className?: string;
}

const OrganicCard = ({ 
  children, 
  className,
  ...props 
}: OrganicCardProps) => {
  return (
    <motion.div
      className={cn(
        "organic-card rounded-[30px] transition-all duration-300", 
        className
      )}
      whileHover={{ 
        y: -5, 
        boxShadow: "0 15px 30px rgba(0,0,0,0.1)" 
      }}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default OrganicCard;
