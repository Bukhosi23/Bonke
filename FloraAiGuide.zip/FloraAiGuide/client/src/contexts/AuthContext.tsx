import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';

// Check if Firebase config is available
const isFirebaseConfigured = (): boolean => {
  return !!import.meta.env.VITE_FIREBASE_API_KEY &&
         !!import.meta.env.VITE_FIREBASE_AUTH_DOMAIN &&
         !!import.meta.env.VITE_FIREBASE_PROJECT_ID;
};

// Try to import auth service or use a mock implementation
let authService: {
  onAuthStateChanged: (callback: (user: User | null) => void) => () => void;
  getCurrentUser: () => User | null;
  registerWithEmail: (email: string, password: string, username: string) => Promise<User>;
  loginWithEmail: (email: string, password: string) => Promise<User>;
  resetPassword: (email: string) => Promise<void>;
  signInWithGoogle: () => Promise<User>;
  signInWithApple: () => Promise<User>;
  logOut: () => Promise<void>;
};

// Mock user for demo purposes when Firebase is not configured
const mockUser = {
  uid: 'mock-uid-123',
  email: 'demo@floraai.com',
  displayName: 'Demo User',
  photoURL: null,
  emailVerified: true,
  isAnonymous: false,
  metadata: {},
  providerData: [],
  refreshToken: '',
  tenantId: null,
  delete: async () => {},
  getIdToken: async () => 'mock-token',
  getIdTokenResult: async () => ({ token: 'mock-token', signInProvider: 'password', expirationTime: '', issuedAtTime: '', authTime: '', claims: {} }),
  reload: async () => {},
  toJSON: () => ({}),
  providerId: 'password',
  phoneNumber: null
} as unknown as User;

try {
  if (isFirebaseConfigured()) {
    // Import the real auth service if Firebase is configured
    authService = require('../lib/authService');
  } else {
    console.warn("Firebase not configured. Using mock authentication service.");
    // Create a mock auth service if Firebase is not configured
    authService = {
      onAuthStateChanged: (callback) => {
        // Simulate auth state change after a delay
        setTimeout(() => callback(null), 500);
        return () => {};
      },
      getCurrentUser: () => null,
      registerWithEmail: async () => {
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate delay
        return mockUser;
      },
      loginWithEmail: async () => {
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate delay
        return mockUser;
      },
      resetPassword: async () => {
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate delay
      },
      signInWithGoogle: async () => {
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate delay
        return mockUser;
      },
      signInWithApple: async () => {
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate delay
        return mockUser;
      },
      logOut: async () => {
        await new Promise(resolve => setTimeout(resolve, 500)); // Simulate delay
      }
    };
  }
} catch (error) {
  console.error("Error loading auth service:", error);
  // Fallback to mock implementation
  authService = {
    onAuthStateChanged: (callback) => {
      setTimeout(() => callback(null), 500);
      return () => {};
    },
    getCurrentUser: () => null,
    registerWithEmail: async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      return mockUser;
    },
    loginWithEmail: async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      return mockUser;
    },
    resetPassword: async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
    },
    signInWithGoogle: async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      return mockUser;
    },
    signInWithApple: async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      return mockUser;
    },
    logOut: async () => {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };
}

interface AuthContextProps {
  currentUser: User | null;
  loading: boolean;
  register: (email: string, password: string, username: string) => Promise<User | null>;
  login: (email: string, password: string) => Promise<User | null>;
  loginWithGoogle: () => Promise<User | null>;
  loginWithApple: () => Promise<User | null>;
  logout: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(authService.getCurrentUser());
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const unsubscribe = authService.onAuthStateChanged((user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const register = async (email: string, password: string, username: string) => {
    try {
      setLoading(true);
      const user = await authService.registerWithEmail(email, password, username);
      toast({
        title: "Account created",
        description: "Welcome to FloraAI! Your account has been created successfully.",
      });
      return user;
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      const user = await authService.loginWithEmail(email, password);
      toast({
        title: "Login successful",
        description: "Welcome back to FloraAI!",
      });
      return user;
    } catch (error) {
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    try {
      setLoading(true);
      const user = await authService.signInWithGoogle();
      toast({
        title: "Google login successful",
        description: "Welcome to FloraAI!",
      });
      return user;
    } catch (error) {
      toast({
        title: "Google login failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const loginWithApple = async () => {
    try {
      setLoading(true);
      const user = await authService.signInWithApple();
      toast({
        title: "Apple login successful",
        description: "Welcome to FloraAI!",
      });
      return user;
    } catch (error) {
      toast({
        title: "Apple login failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await authService.logOut();
      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      });
    } catch (error) {
      toast({
        title: "Logout failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    }
  };

  const sendPasswordReset = async (email: string) => {
    try {
      await authService.resetPassword(email);
      toast({
        title: "Password reset email sent",
        description: "Check your email for a link to reset your password.",
      });
    } catch (error) {
      toast({
        title: "Password reset failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    }
  };

  const value = {
    currentUser,
    loading,
    register,
    login,
    loginWithGoogle,
    loginWithApple,
    logout,
    sendPasswordReset
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}