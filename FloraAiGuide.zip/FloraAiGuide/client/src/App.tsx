import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Identify from "@/pages/Identify";
import Care from "@/pages/Care";
import Community from "@/pages/Community";
import ArTimeTravel from "@/pages/ArTimeTravel";
import CarbonTracker from "@/pages/CarbonTracker";
import Auth from "@/pages/Auth";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { AuthProvider } from "@/contexts/AuthContext";

function Router() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/identify" component={Identify} />
          <Route path="/care" component={Care} />
          <Route path="/community" component={Community} />
          <Route path="/ar-time-travel" component={ArTimeTravel} />
          <Route path="/carbon-tracker" component={CarbonTracker} />
          <Route path="/auth" component={Auth} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </>
  );
}

function App() {
  // Add texture overlay to body
  useEffect(() => {
    document.body.classList.add("texture-overlay");
    return () => {
      document.body.classList.remove("texture-overlay");
    };
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
